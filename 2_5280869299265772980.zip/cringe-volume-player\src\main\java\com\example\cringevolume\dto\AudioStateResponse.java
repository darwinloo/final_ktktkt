package com.example.cringevolume.dto;

import java.time.Instant;

public record AudioStateResponse(
        boolean hasFile,
        String fileName,
        long fileSize,
        String contentType,
        boolean playing,
        int volume,
        String fileUrl,
        Instant updatedAt
) {
}
