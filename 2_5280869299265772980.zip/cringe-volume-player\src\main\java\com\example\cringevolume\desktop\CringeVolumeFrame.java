package com.example.cringevolume.desktop;

import com.example.cringevolume.dto.AudioStateResponse;
import com.example.cringevolume.exception.ApiException;
import com.example.cringevolume.service.AudioPlayerService;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class CringeVolumeFrame extends JFrame {
    private final AudioPlayerService audioPlayerService;
    private final ClipAudioPlayer clipAudioPlayer = new ClipAudioPlayer();
    private final CringeGamePanel gamePanel;

    private final JLabel fileNameLabel = new JLabel("File: none");
    private final JLabel statusLabel = new JLabel("Status: stopped");
    private final JLabel paperworkLabel = new JLabel("Paperwork: 0");
    private final JLabel stampedLabel = new JLabel("Stamped permits: 0");
    private final JLabel shredLabel = new JLabel("Shredder: move to shredder");
    private final JProgressBar volumeBar = new JProgressBar(0, 100);
    private final JButton shredButton = new JButton("Hold shredder");

    private int volume = 35;

    public CringeVolumeFrame(AudioPlayerService audioPlayerService) {
        super("Cringe Volume Player - Decibel Bureau");
        this.audioPlayerService = audioPlayerService;
        this.gamePanel = new CringeGamePanel(new CringeGamePanel.GameListener() {
            @Override
            public void permitStamped() {
                changeVolume(1);
            }

            @Override
            public void shredTick() {
                changeVolume(-1);
            }

            @Override
            public void statsChanged(int paperwork, int stamped, String shredStatus) {
                paperworkLabel.setText("Paperwork: " + paperwork);
                stampedLabel.setText("Stamped permits: " + stamped);
                shredLabel.setText("Shredder: " + shredStatus);
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1180, 760));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(16, 16));
        getContentPane().setBackground(new Color(235, 230, 212));

        add(createHeader(), BorderLayout.NORTH);
        add(createControls(), BorderLayout.WEST);
        add(gamePanel, BorderLayout.CENTER);

        syncState(audioPlayerService.state());
        setSize(1320, 820);

        new Timer(1000, event -> syncState(audioPlayerService.state())).start();
    }

    private JPanel createHeader() {
        JPanel panel = new JPanel(new BorderLayout(16, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 0, 22));
        panel.setBackground(new Color(235, 230, 212));

        JLabel title = new JLabel("Decibel Bureau");
        title.setForeground(new Color(22, 22, 22));
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 44));

        JLabel subtitle = new JLabel("Stamp loudness permits to increase volume. Feed paperwork to the shredder to make it quieter.");
        subtitle.setForeground(new Color(84, 91, 91));
        subtitle.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));

        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setBackground(new Color(235, 230, 212));
        text.add(title);
        text.add(subtitle);

        panel.add(text, BorderLayout.WEST);
        panel.add(createStatePanel(), BorderLayout.EAST);
        return panel;
    }

    private JPanel createStatePanel() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 4, 4));
        panel.setPreferredSize(new Dimension(340, 112));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(22, 22, 22), 2),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        panel.setBackground(new Color(255, 253, 246));
        styleStateLabel(fileNameLabel, new Color(22, 22, 22));
        styleStateLabel(statusLabel, new Color(22, 22, 22));
        styleStateLabel(shredLabel, new Color(22, 22, 22));
        panel.add(fileNameLabel);
        panel.add(statusLabel);
        panel.add(shredLabel);
        return panel;
    }

    private JPanel createControls() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setPreferredSize(new Dimension(360, 0));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(0, 22, 22, 0),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(22, 22, 22), 2),
                        BorderFactory.createEmptyBorder(18, 18, 18, 18)
                )
        ));
        panel.setBackground(new Color(255, 253, 246));

        JButton demoButton = primaryButton("Generate demo track");
        demoButton.addActionListener(event -> uploadDemoTrack());

        JButton uploadButton = secondaryButton("Choose audio file");
        uploadButton.addActionListener(event -> chooseAudioFile());

        JButton playButton = primaryButton("Play");
        playButton.addActionListener(event -> play());

        JButton stopButton = secondaryButton("Stop");
        stopButton.addActionListener(event -> stop());

        shredButton.setBackground(new Color(199, 54, 89));
        shredButton.setForeground(Color.WHITE);
        shredButton.setFocusPainted(false);
        shredButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        shredButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        shredButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent event) {
                gamePanel.setShredding(true);
            }

            @Override
            public void mouseReleased(MouseEvent event) {
                gamePanel.setShredding(false);
            }

            @Override
            public void mouseExited(MouseEvent event) {
                gamePanel.setShredding(false);
            }
        });

        volumeBar.setValue(volume);
        volumeBar.setStringPainted(true);
        volumeBar.setForeground(new Color(8, 117, 110));
        volumeBar.setBackground(new Color(235, 230, 212));

        styleStateLabel(paperworkLabel, new Color(22, 22, 22));
        styleStateLabel(stampedLabel, new Color(22, 22, 22));

        panel.add(sectionTitle("Audio desk"));
        panel.add(Box.createVerticalStrut(10));
        panel.add(demoButton);
        panel.add(Box.createVerticalStrut(10));
        panel.add(uploadButton);
        panel.add(Box.createVerticalStrut(18));
        panel.add(playButton);
        panel.add(Box.createVerticalStrut(10));
        panel.add(stopButton);
        panel.add(Box.createVerticalStrut(22));
        panel.add(sectionTitle("Volume permit"));
        panel.add(Box.createVerticalStrut(10));
        panel.add(volumeBar);
        panel.add(Box.createVerticalStrut(16));
        panel.add(shredButton);
        panel.add(Box.createVerticalStrut(20));
        panel.add(paperworkLabel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(stampedLabel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(helpText());
        return panel;
    }

    private void uploadDemoTrack() {
        try {
            byte[] wav = DemoTrackFactory.createWav();
            AudioStateResponse state = audioPlayerService.uploadBytes(
                    "decibel-bureau-demo.wav",
                    "audio/wav",
                    wav.length,
                    new ByteArrayInputStream(wav)
            );
            syncState(state);
            loadClip();
            message("Demo track loaded. Press Play and start stamping permits.");
        } catch (Exception exception) {
            message("Cannot load demo track: " + exception.getMessage());
        }
    }

    private void chooseAudioFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose audio file");
        chooser.setFileFilter(new FileNameExtensionFilter("Audio files", "wav", "aiff", "aif", "au", "mp3", "ogg", "flac", "m4a"));
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File file = chooser.getSelectedFile();
        try {
            String contentType = Files.probeContentType(file.toPath());
            AudioStateResponse state = audioPlayerService.uploadBytes(
                    file.getName(),
                    contentType == null ? "audio/*" : contentType,
                    file.length(),
                    Files.newInputStream(file.toPath())
            );
            syncState(state);
            loadClip();
            message("File loaded. If Java Sound cannot play it, use WAV or the demo track.");
        } catch (Exception exception) {
            message("Cannot load selected file. Use WAV or demo track. Details: " + exception.getMessage());
        }
    }

    private void play() {
        try {
            AudioStateResponse state = audioPlayerService.play();
            syncState(state);
            loadClip();
            clipAudioPlayer.play();
        } catch (ApiException exception) {
            message(exception.getMessage());
        } catch (Exception exception) {
            message("Java Sound could not open this format. For desktop mode use WAV or the demo track.");
        }
    }

    private void stop() {
        AudioStateResponse state = audioPlayerService.stop();
        syncState(state);
        clipAudioPlayer.stop();
    }

    private void loadClip() throws UnsupportedAudioFileException, LineUnavailableException, IOException {
        clipAudioPlayer.load(audioPlayerService.currentFile().getFile());
        clipAudioPlayer.setVolume(volume);
    }

    private void changeVolume(int delta) {
        int nextVolume = Math.max(0, Math.min(100, volume + delta));
        if (nextVolume == volume) {
            return;
        }
        AudioStateResponse state = audioPlayerService.setVolume(nextVolume);
        syncState(state);
        clipAudioPlayer.setVolume(volume);
    }

    private void syncState(AudioStateResponse state) {
        volume = state.volume();
        gamePanel.setVolume(volume);
        volumeBar.setValue(volume);
        volumeBar.setString(volume + " / 100");
        fileNameLabel.setText("File: " + (state.fileName() == null ? "none" : state.fileName()));
        statusLabel.setText("Status: " + (state.playing() ? "playing" : "stopped"));
    }

    private JButton primaryButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        button.setBackground(new Color(245, 200, 75));
        button.setForeground(new Color(22, 22, 22));
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        button.setFocusPainted(false);
        return button;
    }

    private JButton secondaryButton(String text) {
        JButton button = primaryButton(text);
        button.setBackground(new Color(22, 22, 22));
        button.setForeground(new Color(255, 253, 246));
        return button;
    }

    private JLabel sectionTitle(String text) {
        JLabel label = new JLabel(text);
        label.setAlignmentX(LEFT_ALIGNMENT);
        label.setForeground(new Color(22, 22, 22));
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 19));
        return label;
    }

    private JLabel helpText() {
        JLabel label = new JLabel("<html><body style='width:300px'>Move the stamp with the mouse or arrows. "
                + "Click or press Space over a permit to increase volume by 1. "
                + "Move to the SHREDDER zone and hold Space or the shredder button to decrease volume.</body></html>");
        label.setAlignmentX(LEFT_ALIGNMENT);
        label.setForeground(new Color(84, 91, 91));
        label.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        return label;
    }

    private void styleStateLabel(JLabel label, Color color) {
        label.setForeground(color);
        label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        label.setHorizontalAlignment(SwingConstants.LEFT);
    }

    private void message(String text) {
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, text));
    }
}
