package com.example.cringevolume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CringeVolumePlayerApplication {
    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(CringeVolumePlayerApplication.class);
        application.setHeadless(false);
        application.run(args);
    }
}
