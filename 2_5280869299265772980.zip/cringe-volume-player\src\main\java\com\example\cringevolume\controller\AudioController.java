package com.example.cringevolume.controller;

import com.example.cringevolume.dto.AudioStateResponse;
import com.example.cringevolume.dto.VolumeRequest;
import com.example.cringevolume.service.AudioPlayerService;
import jakarta.validation.Valid;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/audio")
public class AudioController {
    private final AudioPlayerService audioPlayerService;

    public AudioController(AudioPlayerService audioPlayerService) {
        this.audioPlayerService = audioPlayerService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    AudioStateResponse upload(@RequestParam("file") MultipartFile file) {
        return audioPlayerService.upload(file);
    }

    @PostMapping("/play")
    AudioStateResponse play() {
        return audioPlayerService.play();
    }

    @PostMapping("/stop")
    AudioStateResponse stop() {
        return audioPlayerService.stop();
    }

    @PostMapping("/volume")
    AudioStateResponse volume(@Valid @RequestBody VolumeRequest request) {
        return audioPlayerService.setVolume(request.volume());
    }

    @GetMapping("/state")
    AudioStateResponse state() {
        return audioPlayerService.state();
    }

    @GetMapping("/file")
    ResponseEntity<Resource> file() {
        Resource resource = audioPlayerService.currentFile();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(audioPlayerService.currentContentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.inline()
                        .filename(audioPlayerService.currentFileName())
                        .build()
                        .toString())
                .body(resource);
    }
}
