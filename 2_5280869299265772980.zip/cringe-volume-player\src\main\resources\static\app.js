const audio = document.getElementById('audio');
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const ui = {
  fileName: document.getElementById('fileName'),
  playStatus: document.getElementById('playStatus'),
  volumeValue: document.getElementById('volumeValue'),
  meterLabel: document.getElementById('meterLabel'),
  volumeFill: document.getElementById('volumeFill'),
  paperworkValue: document.getElementById('paperworkValue'),
  stampedValue: document.getElementById('stampedValue'),
  shredStatus: document.getElementById('shredStatus'),
  toast: document.getElementById('toast'),
  shredBtn: document.getElementById('shredBtn')
};

const game = {
  permits: [],
  particles: [],
  keys: new Set(),
  paperwork: 0,
  stamped: 0,
  stamp: {
    x: 560,
    y: 610,
    targetX: 560,
    press: 0
  },
  actionHeld: false,
  externalActionHeld: false,
  lastSpawn: 0,
  lastShred: 0,
  volume: 35,
  hasFile: false,
  playing: false
};

document.addEventListener('DOMContentLoaded', () => {
  resizeCanvas();
  bindUi();
  loadState();
  requestAnimationFrame(loop);
});

window.addEventListener('resize', resizeCanvas);

function bindUi() {
  document.getElementById('uploadForm').addEventListener('submit', uploadAudio);
  document.getElementById('demoBtn').addEventListener('click', uploadDemoTrack);
  document.getElementById('playBtn').addEventListener('click', playAudio);
  document.getElementById('stopBtn').addEventListener('click', stopAudio);
  document.getElementById('syncBtn').addEventListener('click', loadState);

  canvas.addEventListener('pointermove', updateStampFromPointer);
  canvas.addEventListener('pointerdown', (event) => {
    updateStampFromPointer(event);
    canvas.setPointerCapture(event.pointerId);
    game.actionHeld = true;
  });
  canvas.addEventListener('pointerup', () => {
    game.actionHeld = false;
  });
  canvas.addEventListener('pointerleave', () => {
    game.actionHeld = false;
  });

  ui.shredBtn.addEventListener('pointerdown', () => {
    game.externalActionHeld = true;
  });
  ui.shredBtn.addEventListener('pointerup', () => {
    game.externalActionHeld = false;
  });
  ui.shredBtn.addEventListener('pointerleave', () => {
    game.externalActionHeld = false;
  });

  window.addEventListener('keydown', (event) => {
    game.keys.add(event.key);
    if (event.code === 'Space') {
      game.actionHeld = true;
      event.preventDefault();
    }
  });
  window.addEventListener('keyup', (event) => {
    game.keys.delete(event.key);
    if (event.code === 'Space') {
      game.actionHeld = false;
      event.preventDefault();
    }
  });

  audio.addEventListener('ended', stopAudio);
}

function updateStampFromPointer(event) {
  const rect = canvas.getBoundingClientRect();
  const scale = canvas.width / rect.width;
  game.stamp.targetX = (event.clientX - rect.left) * scale;
}

async function uploadAudio(event) {
  event.preventDefault();
  const fileInput = document.getElementById('audioFile');
  if (!fileInput.files.length) {
    showToast('Choose an audio file first', true);
    return;
  }
  const body = new FormData();
  body.append('file', fileInput.files[0]);

  const state = await api('/api/audio/upload', {
    method: 'POST',
    body,
    rawBody: true
  });
  applyState(state, true);
  showToast('Audio case accepted. Start stamping permits.');
}

async function uploadDemoTrack() {
  showToast('Generating demo evidence track...');
  const demoFile = createDemoTrack();
  const body = new FormData();
  body.append('file', demoFile);
  const state = await api('/api/audio/upload', {
    method: 'POST',
    body,
    rawBody: true
  });
  applyState(state, true);
  showToast('Demo track loaded. Press Play.');
}

async function playAudio() {
  const state = await api('/api/audio/play', { method: 'POST' });
  applyState(state, false);
  if (audio.src) {
    await audio.play();
  }
}

async function stopAudio() {
  const state = await api('/api/audio/stop', { method: 'POST' });
  applyState(state, false);
  audio.pause();
}

async function loadState() {
  const state = await api('/api/audio/state');
  applyState(state, true);
}

async function setVolume(volume) {
  const nextVolume = Math.max(0, Math.min(100, Math.round(volume)));
  if (nextVolume === game.volume) {
    return;
  }
  game.volume = nextVolume;
  applyVolumeUi();
  audio.volume = nextVolume / 100;
  await api('/api/audio/volume', {
    method: 'POST',
    body: { volume: nextVolume }
  });
}

function applyState(state, refreshAudio) {
  game.hasFile = state.hasFile;
  game.playing = state.playing;
  game.volume = state.volume;
  ui.fileName.textContent = state.fileName || 'none';
  ui.playStatus.textContent = state.playing ? 'playing' : 'stopped';
  applyVolumeUi();

  if (state.fileUrl && refreshAudio) {
    const src = `${state.fileUrl}?v=${encodeURIComponent(state.updatedAt || Date.now())}`;
    if (!audio.src.endsWith(src)) {
      audio.src = src;
    }
  }
  audio.volume = state.volume / 100;
  if (state.playing && audio.src && audio.paused) {
    audio.play().catch(() => {});
  }
}

function applyVolumeUi() {
  ui.volumeValue.textContent = `${game.volume}%`;
  ui.meterLabel.textContent = `${game.volume} / 100`;
  ui.volumeFill.style.width = `${game.volume}%`;
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(900, Math.floor(rect.width * dpr));
  canvas.height = Math.max(560, Math.floor(rect.height * dpr));
  game.stamp.y = canvas.height - 110;
  game.stamp.targetX = clamp(game.stamp.targetX, 80, canvas.width - 80);
  game.stamp.x = clamp(game.stamp.x, 80, canvas.width - 80);
}

function loop(now) {
  updateGame(now);
  drawGame(now);
  requestAnimationFrame(loop);
}

function updateGame(now) {
  if (game.keys.has('ArrowLeft') || game.keys.has('a') || game.keys.has('A')) {
    game.stamp.targetX -= 12;
  }
  if (game.keys.has('ArrowRight') || game.keys.has('d') || game.keys.has('D')) {
    game.stamp.targetX += 12;
  }

  game.stamp.targetX = clamp(game.stamp.targetX, 76, canvas.width - 76);
  game.stamp.x += (game.stamp.targetX - game.stamp.x) * 0.2;

  if (now - game.lastSpawn > spawnDelay()) {
    spawnPermit();
    game.lastSpawn = now;
  }

  const pressed = game.actionHeld || game.externalActionHeld;
  game.stamp.press += ((pressed ? 1 : 0) - game.stamp.press) * 0.24;

  const shredder = getShredder();
  const inShredder = game.stamp.x > shredder.x && game.stamp.x < shredder.x + shredder.width;
  const canShred = pressed && inShredder && game.paperwork > 0;
  ui.shredStatus.textContent = canShred ? 'shredding' : inShredder ? 'ready' : 'move to shredder';

  if (canShred && now - game.lastShred > 125) {
    game.paperwork = Math.max(0, game.paperwork - 1);
    game.lastShred = now;
    setVolume(game.volume - 1).catch(() => {});
    addParticles(shredder.x + shredder.width / 2, shredder.y + 36, '#c73659', 8);
  }

  for (const permit of game.permits) {
    permit.x += permit.speed;
    permit.wobble += 0.035;

    if (pressed && hitsStamp(permit)) {
      permit.dead = true;
      game.paperwork = Math.min(100, game.paperwork + 1);
      game.stamped += 1;
      setVolume(game.volume + 1).catch(() => {});
      addParticles(permit.x + 56, permit.y + 34, '#08756e', 12);
    }

    if (permit.x > canvas.width + 150) {
      permit.dead = true;
    }
  }
  game.permits = game.permits.filter((permit) => !permit.dead);

  for (const particle of game.particles) {
    particle.life -= 1;
    particle.x += particle.vx;
    particle.y += particle.vy;
    particle.vy += 0.06;
  }
  game.particles = game.particles.filter((particle) => particle.life > 0);

  ui.paperworkValue.textContent = game.paperwork;
  ui.stampedValue.textContent = game.stamped;
}

function drawGame(now) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBackground();
  drawConveyor(now);
  drawShredder();
  drawPermits();
  drawStamp();
  drawParticles();
}

function drawBackground() {
  ctx.fillStyle = '#eee4cc';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = 'rgba(23, 23, 23, 0.06)';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 34) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y < canvas.height; y += 34) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  ctx.fillStyle = '#171717';
  ctx.fillRect(0, 0, canvas.width, 84);
  ctx.fillStyle = '#f5c84b';
  ctx.font = `${Math.max(24, canvas.width * 0.026)}px Arial`;
  ctx.fillText('DECIBEL BUREAU', 28, 50);
  ctx.fillStyle = '#fffdf6';
  ctx.font = `${Math.max(13, canvas.width * 0.012)}px Arial`;
  ctx.fillText('Approve loudness permits. Shred approved paperwork to reduce volume.', 30, 72);
}

function drawConveyor(now) {
  const y = canvas.height - 270;
  ctx.fillStyle = '#1d2227';
  roundedRect(30, y, canvas.width - 240, 112, 16, true, false);

  ctx.strokeStyle = '#f5c84b';
  ctx.lineWidth = 3;
  for (let x = 54 - (now / 22) % 48; x < canvas.width - 240; x += 48) {
    ctx.beginPath();
    ctx.moveTo(x, y + 18);
    ctx.lineTo(x + 22, y + 94);
    ctx.stroke();
  }

  ctx.fillStyle = '#fffdf6';
  ctx.font = 'bold 18px Arial';
  ctx.fillText('PERMIT CONVEYOR', 52, y + 33);
}

function drawShredder() {
  const zone = getShredder();
  ctx.fillStyle = '#171717';
  roundedRect(zone.x, zone.y, zone.width, zone.height, 18, true, false);
  ctx.strokeStyle = '#c73659';
  ctx.lineWidth = 4;
  roundedRect(zone.x + 4, zone.y + 4, zone.width - 8, zone.height - 8, 14, false, true);

  ctx.fillStyle = '#ffdfe7';
  ctx.font = 'bold 25px Arial';
  ctx.fillText('SHREDDER', zone.x + 16, zone.y + 38);

  for (let i = 0; i < 6; i += 1) {
    ctx.strokeStyle = `rgba(199, 54, 89, ${0.22 + i * 0.08})`;
    ctx.beginPath();
    ctx.moveTo(zone.x + 18 + i * 22, zone.y + 58);
    ctx.lineTo(zone.x + 18 + i * 22, zone.y + zone.height - 18);
    ctx.stroke();
  }
}

function drawPermits() {
  for (const permit of game.permits) {
    ctx.save();
    ctx.translate(permit.x, permit.y + Math.sin(permit.wobble) * 4);
    ctx.rotate(Math.sin(permit.wobble) * 0.025);

    ctx.fillStyle = '#fffdf6';
    roundedRect(0, 0, 116, 74, 8, true, false);
    ctx.strokeStyle = '#171717';
    ctx.lineWidth = 2;
    roundedRect(0, 0, 116, 74, 8, false, true);

    ctx.fillStyle = '#08756e';
    ctx.fillRect(12, 12, 92, 10);
    ctx.fillStyle = '#171717';
    ctx.font = 'bold 13px Arial';
    ctx.fillText('+1 DB', 12, 45);
    ctx.font = '10px Arial';
    ctx.fillText(`FORM V-${permit.serial}`, 12, 62);
    ctx.restore();
  }
}

function drawStamp() {
  const stamp = game.stamp;
  const pressOffset = stamp.press * 26;
  ctx.save();
  ctx.translate(stamp.x, stamp.y + pressOffset);

  ctx.fillStyle = 'rgba(23, 23, 23, 0.25)';
  ctx.beginPath();
  ctx.ellipse(0, 54, 68, 14, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#7c3a26';
  roundedRect(-28, -92, 56, 76, 14, true, false);
  ctx.strokeStyle = '#171717';
  ctx.lineWidth = 3;
  roundedRect(-28, -92, 56, 76, 14, false, true);

  ctx.fillStyle = '#f5c84b';
  roundedRect(-76, -22, 152, 62, 12, true, false);
  ctx.strokeStyle = '#171717';
  roundedRect(-76, -22, 152, 62, 12, false, true);

  ctx.rotate(-0.05);
  ctx.fillStyle = '#171717';
  ctx.font = 'bold 19px Arial';
  ctx.fillText('APPROVE', -50, 7);
  ctx.font = 'bold 13px Arial';
  ctx.fillText('LOUDNESS', -42, 26);
  ctx.restore();
}

function drawParticles() {
  for (const particle of game.particles) {
    ctx.globalAlpha = Math.max(0, particle.life / particle.maxLife);
    ctx.fillStyle = particle.color;
    ctx.fillRect(particle.x, particle.y, particle.size, particle.size);
  }
  ctx.globalAlpha = 1;
}

function spawnPermit() {
  game.permits.push({
    x: -130,
    y: canvas.height - 245 + Math.random() * 42,
    speed: 2.5 + Math.random() * 2.3 + game.volume * 0.014,
    wobble: Math.random() * 3,
    serial: 100 + Math.floor(Math.random() * 900)
  });
}

function hitsStamp(permit) {
  const stamp = game.stamp;
  const stampLeft = stamp.x - 76;
  const stampRight = stamp.x + 76;
  const stampTop = stamp.y - 22;
  const stampBottom = stamp.y + 52;
  const permitLeft = permit.x;
  const permitRight = permit.x + 116;
  const permitTop = permit.y - 4;
  const permitBottom = permit.y + 78;
  return stampRight > permitLeft
    && stampLeft < permitRight
    && stampBottom > permitTop
    && stampTop < permitBottom;
}

function addParticles(x, y, color, count) {
  for (let i = 0; i < count; i += 1) {
    game.particles.push({
      x,
      y,
      vx: -3 + Math.random() * 6,
      vy: -3 - Math.random() * 3,
      size: 3 + Math.random() * 5,
      color,
      life: 22 + Math.random() * 18,
      maxLife: 40
    });
  }
}

function getShredder() {
  return {
    x: canvas.width - 196,
    y: canvas.height - 300,
    width: 156,
    height: 182
  };
}

function spawnDelay() {
  return Math.max(190, 760 - game.volume * 4);
}

async function api(path, options = {}) {
  const init = {
    method: options.method || 'GET',
    headers: options.rawBody ? {} : { 'Content-Type': 'application/json' }
  };
  if (options.body) {
    init.body = options.rawBody ? options.body : JSON.stringify(options.body);
  }

  const response = await fetch(path, init);
  const text = await response.text();
  const payload = text ? safeJson(text) : null;
  if (!response.ok) {
    const message = payload?.message || text || `HTTP ${response.status}`;
    showToast(message, true);
    throw new Error(message);
  }
  return payload;
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch (error) {
    return text;
  }
}

function showToast(message, error = false) {
  ui.toast.textContent = message;
  ui.toast.classList.toggle('error', error);
  ui.toast.classList.remove('hidden');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => ui.toast.classList.add('hidden'), 4800);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function roundedRect(x, y, width, height, radius, fill, stroke) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  if (fill) {
    ctx.fill();
  }
  if (stroke) {
    ctx.stroke();
  }
}

function createDemoTrack() {
  const sampleRate = 44100;
  const duration = 18;
  const totalSamples = sampleRate * duration;
  const pcm = new Int16Array(totalSamples);

  for (let i = 0; i < totalSamples; i += 1) {
    const t = i / sampleRate;
    const stampCycle = (t * 2.4) % 1;
    const stampEnvelope = Math.exp(-stampCycle * 18);
    const stampThump = Math.sin(2 * Math.PI * (62 + stampEnvelope * 110) * t) * stampEnvelope * 0.48;

    const officeBuzz = (
      Math.sin(2 * Math.PI * 140 * t) +
      Math.sin(2 * Math.PI * 186 * t) * 0.65 +
      Math.sin(2 * Math.PI * 280 * t) * 0.42
    ) * 0.07;

    const shredPhase = (t * 7.5) % 1;
    const shred = (Math.random() * 2 - 1) * Math.exp(-shredPhase * 5) * 0.05;
    const beep = Math.sin(2 * Math.PI * (720 + 80 * Math.sin(t * 5)) * t) * Math.exp(-((t * 1.2) % 1) * 16) * 0.18;

    const sample = Math.tanh(stampThump + officeBuzz + shred + beep);
    pcm[i] = Math.max(-32768, Math.min(32767, Math.floor(sample * 32767)));
  }

  const wav = encodeWav(pcm, sampleRate);
  return new File([wav], 'decibel-bureau-demo.wav', { type: 'audio/wav' });
}

function encodeWav(samples, sampleRate) {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, 'data');
  view.setUint32(40, samples.length * 2, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i += 1) {
    view.setInt16(offset, samples[i], true);
    offset += 2;
  }
  return new Blob([view], { type: 'audio/wav' });
}

function writeString(view, offset, value) {
  for (let i = 0; i < value.length; i += 1) {
    view.setUint8(offset + i, value.charCodeAt(i));
  }
}
