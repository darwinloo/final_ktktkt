package com.example.cringevolume.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public record VolumeRequest(
        @Min(0) @Max(100) int volume
) {
}
