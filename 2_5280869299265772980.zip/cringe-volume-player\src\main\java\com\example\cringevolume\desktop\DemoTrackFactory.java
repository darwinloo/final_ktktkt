package com.example.cringevolume.desktop;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public final class DemoTrackFactory {
    private DemoTrackFactory() {
    }

    public static byte[] createWav() {
        int sampleRate = 44_100;
        int durationSeconds = 18;
        int totalSamples = sampleRate * durationSeconds;
        short[] samples = new short[totalSamples];

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            int beat = (int) Math.floor(t * 2) % 4;
            double kickEnvelope = Math.exp(-((t * 2) % 1) * 14);
            double kick = Math.sin(2 * Math.PI * (48 + kickEnvelope * 80) * t) * kickEnvelope * 0.52;

            double bassGate = beat == 0 || beat == 2 ? 1 : 0.55;
            double bass = Math.sin(2 * Math.PI * 92 * t) * 0.18 * bassGate;

            double dripPhase = (t * 3.5) % 1;
            double dripEnvelope = Math.exp(-dripPhase * 24);
            double drip = Math.sin(2 * Math.PI * (620 + 160 * Math.sin(t * 4)) * t) * dripEnvelope * 0.25;

            double pad = (
                    Math.sin(2 * Math.PI * 185 * t)
                            + Math.sin(2 * Math.PI * 247 * t) * 0.7
                            + Math.sin(2 * Math.PI * 330 * t) * 0.45
            ) * 0.06;

            double wobble = Math.sin(2 * Math.PI * 7.5 * t + Math.sin(t * 2)) * 0.05;
            double sample = Math.tanh(kick + bass + drip + pad + wobble);
            samples[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, Math.floor(sample * Short.MAX_VALUE)));
        }

        try {
            return encodeWav(samples, sampleRate);
        } catch (IOException exception) {
            throw new IllegalStateException("Cannot generate demo track", exception);
        }
    }

    private static byte[] encodeWav(short[] samples, int sampleRate) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int dataSize = samples.length * 2;

        writeAscii(out, "RIFF");
        writeInt(out, 36 + dataSize);
        writeAscii(out, "WAVE");
        writeAscii(out, "fmt ");
        writeInt(out, 16);
        writeShort(out, 1);
        writeShort(out, 1);
        writeInt(out, sampleRate);
        writeInt(out, sampleRate * 2);
        writeShort(out, 2);
        writeShort(out, 16);
        writeAscii(out, "data");
        writeInt(out, dataSize);

        for (short sample : samples) {
            writeShort(out, sample);
        }

        return out.toByteArray();
    }

    private static void writeAscii(ByteArrayOutputStream out, String value) throws IOException {
        out.write(value.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
    }

    private static void writeInt(ByteArrayOutputStream out, int value) {
        out.write(value & 0xff);
        out.write((value >> 8) & 0xff);
        out.write((value >> 16) & 0xff);
        out.write((value >> 24) & 0xff);
    }

    private static void writeShort(ByteArrayOutputStream out, int value) {
        out.write(value & 0xff);
        out.write((value >> 8) & 0xff);
    }
}
