package com.example.cringevolume.desktop;

import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class CringeGamePanel extends JPanel {
    public interface GameListener {
        void permitStamped();

        void shredTick();

        void statsChanged(int paperwork, int stamped, String shredStatus);
    }

    private final GameListener listener;
    private final Random random = new Random();
    private final List<Permit> permits = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private final Set<Integer> keys = new HashSet<>();
    private final Timer timer;

    private double stampX = 560;
    private double stampTargetX = 560;
    private double stampY = 430;
    private double stampPress;
    private boolean actionHeld;
    private boolean externalActionHeld;
    private int paperwork;
    private int stamped;
    private long lastSpawn;
    private long lastShred;
    private int volume = 35;

    public CringeGamePanel(GameListener listener) {
        this.listener = listener;
        setFocusable(true);
        setBackground(new Color(235, 230, 212));
        setDoubleBuffered(true);

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent event) {
                stampTargetX = event.getX();
            }

            @Override
            public void mouseDragged(MouseEvent event) {
                stampTargetX = event.getX();
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent event) {
                requestFocusInWindow();
                actionHeld = true;
            }

            @Override
            public void mouseReleased(MouseEvent event) {
                actionHeld = false;
            }

            @Override
            public void mouseExited(MouseEvent event) {
                actionHeld = false;
            }
        });

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                keys.add(event.getKeyCode());
                if (event.getKeyCode() == KeyEvent.VK_SPACE) {
                    actionHeld = true;
                }
            }

            @Override
            public void keyReleased(KeyEvent event) {
                keys.remove(event.getKeyCode());
                if (event.getKeyCode() == KeyEvent.VK_SPACE) {
                    actionHeld = false;
                }
            }
        });

        timer = new Timer(16, event -> tick());
        timer.start();
    }

    public void setVolume(int volume) {
        this.volume = Math.max(0, Math.min(100, volume));
    }

    public void setShredding(boolean shredding) {
        this.externalActionHeld = shredding;
    }

    private void tick() {
        long now = System.currentTimeMillis();
        stampY = getHeight() - 118;

        if (keys.contains(KeyEvent.VK_LEFT) || keys.contains(KeyEvent.VK_A)) {
            stampTargetX -= 13;
        }
        if (keys.contains(KeyEvent.VK_RIGHT) || keys.contains(KeyEvent.VK_D)) {
            stampTargetX += 13;
        }
        stampTargetX = clamp(stampTargetX, 72, Math.max(72, getWidth() - 72));
        stampX += (stampTargetX - stampX) * 0.2;

        long spawnDelay = Math.max(190, 760 - volume * 4L);
        if (now - lastSpawn > spawnDelay) {
            spawnPermit();
            lastSpawn = now;
        }

        boolean pressed = actionHeld || externalActionHeld;
        stampPress += ((pressed ? 1 : 0) - stampPress) * 0.22;

        ShredZone zone = shredZone();
        boolean inShredZone = stampX > zone.x && stampX < zone.x + zone.width;
        boolean canShred = pressed && inShredZone && paperwork > 0;
        if (canShred && now - lastShred > 125) {
            paperwork = Math.max(0, paperwork - 1);
            lastShred = now;
            addParticles(zone.x + zone.width / 2, zone.y + 36, new Color(199, 54, 89), 8);
            listener.shredTick();
        }

        for (Iterator<Permit> iterator = permits.iterator(); iterator.hasNext(); ) {
            Permit permit = iterator.next();
            permit.x += permit.speed;
            permit.wobble += 0.035;

            if (pressed && hitsStamp(permit)) {
                iterator.remove();
                paperwork = Math.min(100, paperwork + 1);
                stamped++;
                addParticles((int) permit.x + 54, (int) permit.y + 34, new Color(8, 117, 110), 12);
                listener.permitStamped();
            } else if (permit.x > getWidth() + 140) {
                iterator.remove();
            }
        }

        for (Iterator<Particle> iterator = particles.iterator(); iterator.hasNext(); ) {
            Particle particle = iterator.next();
            particle.life--;
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.vy += 0.06;
            if (particle.life <= 0) {
                iterator.remove();
            }
        }

        String status = canShred ? "shredding" : inShredZone ? "ready" : "move to shredder";
        listener.statsChanged(paperwork, stamped, status);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawBackground(g);
        drawConveyor(g);
        drawShredder(g);
        drawPermits(g);
        drawStamp(g);
        drawParticles(g);
        g.dispose();
    }

    private void drawBackground(Graphics2D g) {
        g.setColor(new Color(235, 230, 212));
        g.fillRect(0, 0, getWidth(), getHeight());

        g.setColor(new Color(22, 22, 22, 18));
        for (int x = 0; x < getWidth(); x += 34) {
            g.drawLine(x, 0, x, getHeight());
        }
        for (int y = 0; y < getHeight(); y += 34) {
            g.drawLine(0, y, getWidth(), y);
        }

        g.setColor(new Color(22, 22, 22));
        g.fillRect(0, 0, getWidth(), 72);
        g.setColor(new Color(245, 200, 75));
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 28));
        g.drawString("DECIBEL BUREAU: STAMP LOUDNESS PERMITS", 24, 45);

        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        g.setColor(new Color(255, 253, 246));
        g.drawString("Mouse/Arrows move stamp. Click or Space stamps forms. Shredder zone drains volume.", 26, 66);
    }

    private void drawConveyor(Graphics2D g) {
        int y = getHeight() - 270;
        g.setColor(new Color(30, 34, 39));
        g.fillRoundRect(28, y, Math.max(0, getWidth() - 240), 112, 16, 16);

        g.setColor(new Color(245, 200, 75));
        g.setStroke(new BasicStroke(3));
        for (int x = 48; x < getWidth() - 240; x += 48) {
            g.drawLine(x, y + 20, x + 22, y + 92);
        }

        g.setColor(new Color(255, 253, 246));
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("PERMIT CONVEYOR", 48, y + 32);
    }

    private void drawShredder(Graphics2D g) {
        ShredZone zone = shredZone();
        g.setColor(new Color(22, 22, 22));
        g.fillRoundRect(zone.x, zone.y, zone.width, zone.height, 18, 18);
        g.setColor(new Color(199, 54, 89));
        g.setStroke(new BasicStroke(4));
        g.drawRoundRect(zone.x + 4, zone.y + 4, zone.width - 8, zone.height - 8, 14, 14);

        g.setColor(new Color(255, 223, 231));
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 26));
        g.drawString("SHREDDER", zone.x + 18, zone.y + 38);

        g.setStroke(new BasicStroke(2));
        for (int i = 0; i < 6; i++) {
            int x = zone.x + 18 + i * 22;
            g.setColor(new Color(199, 54, 89, 80 + i * 20));
            g.drawLine(x, zone.y + 58, x, zone.y + zone.height - 18);
        }
    }

    private void drawPermits(Graphics2D g) {
        for (Permit permit : permits) {
            Graphics2D copy = (Graphics2D) g.create();
            copy.translate(permit.x, permit.y + Math.sin(permit.wobble) * 4);
            copy.rotate(Math.sin(permit.wobble) * 0.025);

            copy.setColor(new Color(255, 253, 246));
            copy.fill(new RoundRectangle2D.Double(0, 0, 116, 74, 8, 8));
            copy.setColor(new Color(22, 22, 22));
            copy.setStroke(new BasicStroke(2));
            copy.draw(new RoundRectangle2D.Double(0, 0, 116, 74, 8, 8));

            copy.setColor(new Color(8, 117, 110));
            copy.fillRect(12, 12, 92, 10);
            copy.setColor(new Color(22, 22, 22));
            copy.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
            copy.drawString("+1 DB", 12, 45);
            copy.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
            copy.drawString("FORM V-" + permit.serial, 12, 62);
            copy.dispose();
        }
    }

    private void drawStamp(Graphics2D g) {
        Graphics2D copy = (Graphics2D) g.create();
        double pressOffset = stampPress * 26;
        copy.translate(stampX, stampY + pressOffset);

        copy.setColor(new Color(22, 22, 22, 55));
        copy.fillOval(-62, 46, 124, 22);

        copy.setColor(new Color(124, 58, 38));
        copy.fillRoundRect(-28, -92, 56, 76, 14, 14);
        copy.setColor(new Color(22, 22, 22));
        copy.setStroke(new BasicStroke(3));
        copy.drawRoundRect(-28, -92, 56, 76, 14, 14);

        copy.setColor(new Color(245, 200, 75));
        copy.fillRoundRect(-76, -22, 152, 62, 12, 12);
        copy.setColor(new Color(22, 22, 22));
        copy.drawRoundRect(-76, -22, 152, 62, 12, 12);

        AffineTransform original = copy.getTransform();
        copy.rotate(-0.05);
        copy.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 19));
        copy.drawString("APPROVE", -50, 7);
        copy.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        copy.drawString("LOUDNESS", -42, 26);
        copy.setTransform(original);
        copy.dispose();
    }

    private void drawParticles(Graphics2D g) {
        for (Particle particle : particles) {
            int alpha = Math.max(0, Math.min(255, (int) (255 * particle.life / (double) particle.maxLife)));
            g.setColor(new Color(particle.color.getRed(), particle.color.getGreen(), particle.color.getBlue(), alpha));
            g.fillRect((int) particle.x, (int) particle.y, particle.size, particle.size);
        }
    }

    private void spawnPermit() {
        Permit permit = new Permit();
        permit.x = -130;
        permit.y = getHeight() - 245 + random.nextInt(42);
        permit.speed = 2.5 + random.nextDouble() * 2.3 + volume * 0.014;
        permit.serial = 100 + random.nextInt(900);
        permits.add(permit);
    }

    private boolean hitsStamp(Permit permit) {
        double stampLeft = stampX - 76;
        double stampRight = stampX + 76;
        double stampTop = stampY - 22;
        double stampBottom = stampY + 52;
        double permitLeft = permit.x;
        double permitRight = permit.x + 116;
        double permitTop = permit.y - 4;
        double permitBottom = permit.y + 78;
        return stampRight > permitLeft
                && stampLeft < permitRight
                && stampBottom > permitTop
                && stampTop < permitBottom;
    }

    private void addParticles(int x, int y, Color color, int count) {
        for (int i = 0; i < count; i++) {
            Particle particle = new Particle();
            particle.x = x;
            particle.y = y;
            particle.vx = -3 + random.nextDouble() * 6;
            particle.vy = -3 - random.nextDouble() * 3;
            particle.size = 3 + random.nextInt(5);
            particle.color = color;
            particle.life = 22 + random.nextInt(18);
            particle.maxLife = 40;
            particles.add(particle);
        }
    }

    private ShredZone shredZone() {
        return new ShredZone(Math.max(24, getWidth() - 196), Math.max(132, getHeight() - 300), 156, 182);
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private record ShredZone(int x, int y, int width, int height) {
    }

    private static class Permit {
        double x;
        double y;
        double speed;
        double wobble;
        int serial;
    }

    private static class Particle {
        double x;
        double y;
        double vx;
        double vy;
        int size;
        Color color;
        int life;
        int maxLife;
    }
}
