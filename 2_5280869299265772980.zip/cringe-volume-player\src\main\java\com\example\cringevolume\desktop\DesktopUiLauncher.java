package com.example.cringevolume.desktop;

import com.example.cringevolume.service.AudioPlayerService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.swing.SwingUtilities;

@Component
@ConditionalOnProperty(name = "app.ui", havingValue = "desktop", matchIfMissing = true)
public class DesktopUiLauncher {
    private final AudioPlayerService audioPlayerService;

    public DesktopUiLauncher(AudioPlayerService audioPlayerService) {
        this.audioPlayerService = audioPlayerService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void openDesktopUi() {
        SwingUtilities.invokeLater(() -> {
            CringeVolumeFrame frame = new CringeVolumeFrame(audioPlayerService);
            frame.setVisible(true);
        });
    }
}
