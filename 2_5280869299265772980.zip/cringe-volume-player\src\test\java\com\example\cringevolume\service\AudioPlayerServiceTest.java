package com.example.cringevolume.service;

import com.example.cringevolume.exception.ApiException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.mock.web.MockMultipartFile;

import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class AudioPlayerServiceTest {
    @TempDir
    Path tempDir;

    @Test
    void uploadPlayStopAndVolumeChangeUpdateState() throws Exception {
        AudioPlayerService service = new AudioPlayerService(tempDir.toString());
        service.init();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "track.mp3",
                "audio/mpeg",
                new byte[]{1, 2, 3}
        );

        var uploaded = service.upload(file);
        var playing = service.play();
        var loud = service.setVolume(99);
        var stopped = service.stop();

        assertThat(uploaded.hasFile()).isTrue();
        assertThat(uploaded.fileName()).isEqualTo("track.mp3");
        assertThat(playing.playing()).isTrue();
        assertThat(loud.volume()).isEqualTo(99);
        assertThat(stopped.playing()).isFalse();
    }

    @Test
    void playWithoutFileFails() throws Exception {
        AudioPlayerService service = new AudioPlayerService(tempDir.toString());
        service.init();

        assertThatThrownBy(service::play)
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("Upload audio");
    }
}
