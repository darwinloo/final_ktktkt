package com.example.cringevolume.service;

import com.example.cringevolume.dto.AudioStateResponse;
import com.example.cringevolume.exception.ApiException;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
public class AudioPlayerService {
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
            "mp3", "wav", "ogg", "m4a", "aac", "flac", "webm"
    );

    private final Path storageDir;

    private Path uploadedFile;
    private String originalFileName;
    private String contentType;
    private long fileSize;
    private boolean playing;
    private int volume = 35;
    private Instant updatedAt = Instant.now();

    public AudioPlayerService(@Value("${app.audio.storage-dir}") String storageDir) {
        this.storageDir = Path.of(storageDir).toAbsolutePath().normalize();
    }

    @PostConstruct
    void init() throws IOException {
        Files.createDirectories(storageDir);
    }

    public synchronized AudioStateResponse upload(MultipartFile file) {
        if (file.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Audio file is empty");
        }
        String cleanName = StringUtils.cleanPath(file.getOriginalFilename() == null
                ? "audio-file"
                : file.getOriginalFilename());
        try {
            return uploadBytes(cleanName, file.getContentType(), file.getSize(), file.getInputStream());
        } catch (IOException exception) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Cannot save audio file");
        }
    }

    public synchronized AudioStateResponse uploadBytes(String fileName,
                                                       String contentType,
                                                       long size,
                                                       InputStream inputStream) {
        String cleanName = StringUtils.cleanPath(fileName == null ? "audio-file" : fileName);
        validateAudioFile(cleanName, contentType);
        String storedName = UUID.randomUUID() + "-" + cleanName.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path target = storageDir.resolve(storedName).normalize();
        if (!target.startsWith(storageDir)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Invalid file name");
        }

        try (inputStream) {
            Files.copy(inputStream, target, StandardCopyOption.REPLACE_EXISTING);
            deletePreviousFile();
            uploadedFile = target;
            originalFileName = cleanName;
            this.contentType = contentType == null ? "application/octet-stream" : contentType;
            fileSize = size;
            playing = false;
            updatedAt = Instant.now();
            return state();
        } catch (IOException exception) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Cannot save audio file");
        }
    }

    public synchronized AudioStateResponse play() {
        requireFile();
        playing = true;
        updatedAt = Instant.now();
        return state();
    }

    public synchronized AudioStateResponse stop() {
        playing = false;
        updatedAt = Instant.now();
        return state();
    }

    public synchronized AudioStateResponse setVolume(int newVolume) {
        volume = Math.max(0, Math.min(100, newVolume));
        updatedAt = Instant.now();
        return state();
    }

    public synchronized AudioStateResponse state() {
        boolean hasFile = uploadedFile != null && Files.exists(uploadedFile);
        return new AudioStateResponse(
                hasFile,
                hasFile ? originalFileName : null,
                hasFile ? fileSize : 0,
                hasFile ? contentType : null,
                hasFile && playing,
                volume,
                hasFile ? "/api/audio/file" : null,
                updatedAt
        );
    }

    public synchronized Resource currentFile() {
        requireFile();
        try {
            return new UrlResource(uploadedFile.toUri());
        } catch (MalformedURLException exception) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Cannot read audio file");
        }
    }

    public synchronized String currentContentType() {
        requireFile();
        return contentType;
    }

    public synchronized String currentFileName() {
        requireFile();
        return originalFileName;
    }

    private void validateAudioFile(String fileName, String contentType) {
        String extension = "";
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex >= 0 && dotIndex < fileName.length() - 1) {
            extension = fileName.substring(dotIndex + 1).toLowerCase(Locale.ROOT);
        }
        boolean extensionAllowed = ALLOWED_EXTENSIONS.contains(extension);
        boolean contentTypeAllowed = contentType != null && contentType.startsWith("audio/");
        if (!extensionAllowed && !contentTypeAllowed) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Upload an audio file: mp3, wav, ogg, m4a, aac, flac or webm");
        }
    }

    private void requireFile() {
        if (uploadedFile == null || !Files.exists(uploadedFile)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Upload audio before this action");
        }
    }

    private void deletePreviousFile() throws IOException {
        if (uploadedFile != null && Files.exists(uploadedFile)) {
            Files.delete(uploadedFile);
        }
    }
}
