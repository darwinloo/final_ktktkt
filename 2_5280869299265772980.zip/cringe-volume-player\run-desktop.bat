@echo off
cd /d "%~dp0"
echo Starting Cringe Volume Player desktop app...

if "%JAVA_HOME%"=="" (
  echo.
  echo JAVA_HOME is not set.
  echo Install JDK 17 or newer, then set JAVA_HOME to the JDK folder.
  echo Example: C:\Program Files\Eclipse Adoptium\jdk-17...
  echo.
  pause
  exit /b 1
)

if not exist "%JAVA_HOME%\bin\java.exe" (
  echo.
  echo JAVA_HOME does not point to a valid JDK:
  echo %JAVA_HOME%
  echo.
  pause
  exit /b 1
)

call mvnw.cmd spring-boot:run
pause
