package com.example.cringevolume.dto;

public record MessageResponse(String message) {
}
