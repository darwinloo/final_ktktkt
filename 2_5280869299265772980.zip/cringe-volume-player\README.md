# Cringe Volume Player: Decibel Bureau

Spring Boot client-server audio player for the `Cringe Volume` lab.

Main cringe idea: volume is controlled through a fake bureaucratic office.
Loudness permits move on a conveyor. The user moves a huge office stamp with the mouse or arrow keys.
Click or press `Space` over a permit to stamp it. Every stamped permit sends `POST /api/audio/volume` and increases volume by `+1`.
To make audio quieter, move the stamp to the `SHREDDER` zone and hold `Space` or the `Hold shredder` button. The shredder removes approved paperwork and decreases volume by `-1`.

This is not a casino mechanic.

## What Is Inside

- Desktop UI on Java Swing.
- Spring Boot REST API.
- Backend stores current file, playback status and volume.
- Audio upload endpoint.
- Built-in generated demo track.
- Docker Compose backend/web fallback on port `8070`.

## Main Desktop Run

Requirements: `JDK 17` or newer.

Open PowerShell in the project folder:

```powershell
cd "C:\Users\hykine\Documents\Codex\2026-06-10\2-spring-boot\cringe-volume-player"
```

Run:

```powershell
.\mvnw.cmd spring-boot:run
```

The desktop window `Cringe Volume Player - Decibel Bureau` opens automatically.

Shortcut:

```powershell
.\run-desktop.bat
```

## IntelliJ IDEA Run

1. `File -> Open`
2. Select `cringe-volume-player/pom.xml`
3. Project SDK: `JDK 17`
4. Run class:

```text
CringeVolumePlayerApplication
```

## How To Use

1. Click `Generate demo track` or choose your own audio file.
2. Click `Play`.
3. Move the stamp with mouse or `Left/Right` arrows.
4. Click or press `Space` over a permit on the conveyor to increase volume.
5. Move the stamp to `SHREDDER` and hold `Space` or `Hold shredder` to decrease volume.

For desktop playback, `wav` is the safest format because Java Sound supports it reliably without extra libraries.
The backend accepts common audio MIME types, but desktop playback support depends on Java Sound.

## REST API

The backend is available in both desktop and Docker/web modes.

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/audio/upload` | Upload audio file through multipart field `file` |
| `POST` | `/api/audio/play` | Start playback |
| `POST` | `/api/audio/stop` | Stop playback |
| `POST` | `/api/audio/volume` | Change volume, JSON: `{ "volume": 50 }` |
| `GET` | `/api/audio/state` | Get current player state |
| `GET` | `/api/audio/file` | Download current uploaded audio file |

## Requirements Match

| Requirement | Implementation |
| --- | --- |
| Client-server audio player | Swing client + Spring Boot backend |
| Backend: Spring Boot + Docker | Spring Boot app with Dockerfile and Compose |
| Custom inconvenient volume control | Decibel Bureau stamp and shredder mechanic |
| `POST /api/audio/upload` | `AudioController.upload` |
| `POST /api/audio/play` | `AudioController.play` |
| `POST /api/audio/stop` | `AudioController.stop` |
| `POST /api/audio/volume` | `AudioController.volume` |
| `GET /api/audio/state` | `AudioController.state` |
| Backend stores uploaded file | `AudioPlayerService.uploadBytes` |
| Backend stores playback status | `playing` field in `AudioPlayerService` |
| Backend stores current volume | `volume` field in `AudioPlayerService` |
| Docker Compose one command | `docker compose up --build` |

## Docker Compose

Docker mode runs backend and web fallback, because a container cannot open the desktop Swing window.

```powershell
docker compose up --build
```

Open:

```text
http://localhost:8070
```

Stop:

```powershell
docker compose down
```

## Test

```powershell
.\mvnw.cmd test
```

If Maven says `JAVA_HOME environment variable is not defined correctly`, set `JAVA_HOME` to JDK 17 or configure JDK 17 in IntelliJ IDEA.
