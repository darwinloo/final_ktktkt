package com.example.cringevolume.desktop;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.File;
import java.io.IOException;

public class ClipAudioPlayer {
    private Clip clip;
    private File loadedFile;
    private int volume = 35;

    public void load(File file) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
        if (loadedFile != null && loadedFile.equals(file) && clip != null) {
            return;
        }
        close();
        try (AudioInputStream source = AudioSystem.getAudioInputStream(file)) {
            AudioFormat format = source.getFormat();
            AudioInputStream playableStream = source;
            if (format.getEncoding() != AudioFormat.Encoding.PCM_SIGNED) {
                AudioFormat decodedFormat = new AudioFormat(
                        AudioFormat.Encoding.PCM_SIGNED,
                        format.getSampleRate(),
                        16,
                        format.getChannels(),
                        format.getChannels() * 2,
                        format.getSampleRate(),
                        false
                );
                playableStream = AudioSystem.getAudioInputStream(decodedFormat, source);
            }
            clip = AudioSystem.getClip();
            clip.open(playableStream);
            loadedFile = file;
            setVolume(volume);
        }
    }

    public void play() {
        if (clip == null) {
            return;
        }
        if (clip.getFramePosition() >= clip.getFrameLength()) {
            clip.setFramePosition(0);
        }
        clip.start();
    }

    public void stop() {
        if (clip == null) {
            return;
        }
        clip.stop();
        clip.setFramePosition(0);
    }

    public void setVolume(int volume) {
        this.volume = Math.max(0, Math.min(100, volume));
        if (clip == null) {
            return;
        }
        if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl control = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float gain = this.volume == 0
                    ? control.getMinimum()
                    : (float) (20.0 * Math.log10(this.volume / 100.0));
            control.setValue(Math.max(control.getMinimum(), Math.min(control.getMaximum(), gain)));
        }
    }

    public void close() {
        if (clip != null) {
            clip.stop();
            clip.close();
            clip = null;
            loadedFile = null;
        }
    }
}
