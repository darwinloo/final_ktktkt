package com.example.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record SetSecurityCodeRequest(
        String currentSecurityCode,
        @NotBlank @Size(min = 4, max = 32) String newSecurityCode
) {
}
