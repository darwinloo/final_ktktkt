package com.example.notification.dto;

import com.example.notification.domain.NotificationStatus;

import java.time.Instant;
import java.util.UUID;

public record NotificationResponse(
        UUID id,
        String recipient,
        String subject,
        String body,
        String type,
        String metadata,
        NotificationStatus status,
        Instant createdAt
) {
}
