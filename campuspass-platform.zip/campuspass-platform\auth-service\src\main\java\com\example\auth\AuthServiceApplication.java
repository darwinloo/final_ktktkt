package com.example.auth;

import com.example.auth.domain.Role;
import com.example.auth.domain.User;
import com.example.auth.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class AuthServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner seedUsers(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            createUserIfMissing(userRepository, passwordEncoder, "Maksim Orlov", "owner@campuspass.local", Role.ADMIN);
            createUserIfMissing(userRepository, passwordEncoder, "Alina Petrova", "curator@campuspass.local", Role.MODERATOR);
            createUserIfMissing(userRepository, passwordEncoder, "Daniil Morozov", "attendee@campuspass.local", Role.USER);
        };
    }

    private void createUserIfMissing(UserRepository userRepository,
                                     PasswordEncoder passwordEncoder,
                                     String name,
                                     String email,
                                     Role role) {
        userRepository.findByEmail(email).ifPresentOrElse(user -> {
        }, () -> {
            User user = new User();
            user.setName(name);
            user.setEmail(email);
            user.setPasswordHash(passwordEncoder.encode("Passw0rd!"));
            user.setSecurityCodeHash(passwordEncoder.encode("8642"));
            user.setRole(role);
            user.setBio("CampusPass demo account for role " + role.name() + ".");
            user.setEmailVerified(true);
            userRepository.save(user);
        });
    }
}
