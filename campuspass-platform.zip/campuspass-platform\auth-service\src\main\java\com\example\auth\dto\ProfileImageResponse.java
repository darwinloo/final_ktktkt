package com.example.auth.dto;

import java.util.UUID;

public record ProfileImageResponse(
        UUID id,
        String fileName,
        String contentType,
        long size,
        String url
) {
}
