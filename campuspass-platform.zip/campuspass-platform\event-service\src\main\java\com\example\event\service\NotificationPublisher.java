package com.example.event.service;

import com.example.event.config.RabbitMqConfig;
import com.example.event.domain.ApplicationStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class NotificationPublisher {
    private static final Logger log = LoggerFactory.getLogger(NotificationPublisher.class);

    private final RabbitTemplate rabbitTemplate;

    public NotificationPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void applicationSubmitted(String to, String eventTitle) {
        send(Map.of(
                "to", to,
                "subject", "Application submitted",
                "body", "Your application for event '" + eventTitle + "' was submitted.",
                "type", "APPLICATION_SUBMITTED",
                "eventTitle", eventTitle
        ));
    }

    public void applicationStatusChanged(String to, String eventTitle, ApplicationStatus status) {
        send(Map.of(
                "to", to,
                "subject", "Application status changed",
                "body", "Your application for event '" + eventTitle + "' is now " + status + ".",
                "type", "APPLICATION_STATUS_CHANGED",
                "eventTitle", eventTitle,
                "status", status.name()
        ));
    }

    private void send(Map<String, String> payload) {
        try {
            rabbitTemplate.convertAndSend(
                    RabbitMqConfig.NOTIFICATION_EXCHANGE,
                    RabbitMqConfig.EMAIL_ROUTING_KEY,
                    payload
            );
        } catch (RuntimeException exception) {
            log.warn("RabbitMQ is unavailable, notification event was not delivered: {}", payload);
        }
    }
}
