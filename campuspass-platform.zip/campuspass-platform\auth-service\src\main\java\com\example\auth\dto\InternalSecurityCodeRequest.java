package com.example.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public record InternalSecurityCodeRequest(
        @NotNull UUID userId,
        @NotBlank String securityCode
) {
}
