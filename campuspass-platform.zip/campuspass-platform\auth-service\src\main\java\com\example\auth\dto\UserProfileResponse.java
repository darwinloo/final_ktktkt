package com.example.auth.dto;

import com.example.auth.domain.Role;

import java.util.List;
import java.util.UUID;

public record UserProfileResponse(
        UUID id,
        String name,
        String email,
        Role role,
        String bio,
        boolean emailVerified,
        List<ProfileImageResponse> images
) {
}
