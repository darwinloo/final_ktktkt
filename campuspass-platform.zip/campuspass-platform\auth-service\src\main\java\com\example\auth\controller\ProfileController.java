package com.example.auth.controller;

import com.example.auth.domain.ProfileImage;
import com.example.auth.dto.ChangeEmailRequest;
import com.example.auth.dto.MessageResponse;
import com.example.auth.dto.ProfileImageResponse;
import com.example.auth.dto.SetSecurityCodeRequest;
import com.example.auth.dto.UpdateProfileRequest;
import com.example.auth.dto.UserProfileResponse;
import com.example.auth.service.ProfileService;
import jakarta.validation.Valid;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {
    private final ProfileService profileService;

    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @GetMapping("/me")
    UserProfileResponse me() {
        return profileService.currentProfile();
    }

    @PutMapping("/me")
    UserProfileResponse update(@Valid @RequestBody UpdateProfileRequest request) {
        return profileService.updateProfile(request);
    }

    @PutMapping("/email")
    MessageResponse changeEmail(@Valid @RequestBody ChangeEmailRequest request) {
        return profileService.changeEmail(request);
    }

    @PostMapping("/security-code")
    MessageResponse setSecurityCode(@Valid @RequestBody SetSecurityCodeRequest request) {
        return profileService.setSecurityCode(request);
    }

    @PostMapping(value = "/images", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    ProfileImageResponse uploadImage(@RequestParam("file") MultipartFile file) {
        return profileService.uploadImage(file);
    }

    @GetMapping("/images/{imageId}")
    ResponseEntity<byte[]> getImage(@PathVariable UUID imageId) {
        ProfileImage image = profileService.getCurrentUserImage(imageId);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(image.getContentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.inline()
                        .filename(image.getFileName())
                        .build()
                        .toString())
                .body(image.getData());
    }

    @DeleteMapping("/images/{imageId}")
    MessageResponse deleteImage(@PathVariable UUID imageId,
                                @RequestHeader("X-Security-Code") String securityCode) {
        return profileService.deleteImage(imageId, securityCode);
    }
}
