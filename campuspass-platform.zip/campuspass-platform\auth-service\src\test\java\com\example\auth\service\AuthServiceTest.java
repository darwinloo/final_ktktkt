package com.example.auth.service;

import com.example.auth.domain.Role;
import com.example.auth.domain.User;
import com.example.auth.dto.RegisterRequest;
import com.example.auth.repository.RefreshTokenRepository;
import com.example.auth.repository.UserRepository;
import com.example.common.security.JwtTokenService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AuthServiceTest {
    @Test
    void registerCreatesUnverifiedUserAndSendsVerificationEvent() {
        UserRepository userRepository = mock(UserRepository.class);
        RefreshTokenRepository refreshTokenRepository = mock(RefreshTokenRepository.class);
        NotificationClient notificationClient = mock(NotificationClient.class);
        ProfileService profileService = mock(ProfileService.class);
        JwtTokenService jwtTokenService = new JwtTokenService(
                "test-secret-key-with-at-least-32-characters",
                "test-suite"
        );
        var passwordEncoder = new BCryptPasswordEncoder();
        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);
        when(userRepository.findByEmail("new@example.com")).thenReturn(Optional.empty());
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        AuthService authService = new AuthService(
                userRepository,
                refreshTokenRepository,
                passwordEncoder,
                jwtTokenService,
                notificationClient,
                profileService,
                60,
                7,
                "http://localhost:8080"
        );

        var response = authService.register(new RegisterRequest(
                "New User",
                "New@Example.COM",
                "password"
        ));

        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(userCaptor.capture());
        User savedUser = userCaptor.getValue();

        assertThat(savedUser.getEmail()).isEqualTo("new@example.com");
        assertThat(savedUser.getRole()).isEqualTo(Role.USER);
        assertThat(savedUser.isEmailVerified()).isFalse();
        assertThat(savedUser.getEmailVerificationToken()).isNotBlank();
        assertThat(passwordEncoder.matches("password", savedUser.getPasswordHash())).isTrue();
        assertThat(response.verificationToken()).isEqualTo(savedUser.getEmailVerificationToken());
        verify(notificationClient).sendVerificationEmail(
                eq("new@example.com"),
                contains(savedUser.getEmailVerificationToken()),
                eq(savedUser.getEmailVerificationToken())
        );
    }
}
