package com.example.notification.service;

import com.example.notification.domain.Notification;
import com.example.notification.dto.EmailNotificationRequest;
import com.example.notification.dto.NotificationResponse;
import com.example.notification.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class NotificationService {
    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Transactional
    public NotificationResponse create(EmailNotificationRequest request) {
        Notification notification = new Notification();
        notification.setRecipient(request.to());
        notification.setSubject(request.subject());
        notification.setBody(request.body());
        notification.setType(request.type());
        notification.setMetadata(request.metadata() == null ? null : request.metadata().toString());
        return toResponse(notificationRepository.save(notification));
    }

    @Transactional
    public NotificationResponse createFromEvent(Map<String, Object> event) {
        Map<String, String> metadata = new LinkedHashMap<>();
        event.forEach((key, value) -> {
            if (!List.of("to", "subject", "body", "type").contains(key)) {
                metadata.put(key, Objects.toString(value, ""));
            }
        });
        return create(new EmailNotificationRequest(
                Objects.toString(event.get("to"), ""),
                Objects.toString(event.get("subject"), ""),
                Objects.toString(event.get("body"), ""),
                Objects.toString(event.get("type"), "UNKNOWN"),
                metadata
        ));
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> findAll() {
        return notificationRepository.findAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> findByRecipient(String recipient) {
        return notificationRepository.findByRecipientOrderByCreatedAtDesc(recipient)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    private NotificationResponse toResponse(Notification notification) {
        return new NotificationResponse(
                notification.getId(),
                notification.getRecipient(),
                notification.getSubject(),
                notification.getBody(),
                notification.getType(),
                notification.getMetadata(),
                notification.getStatus(),
                notification.getCreatedAt()
        );
    }
}
