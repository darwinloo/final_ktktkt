package com.example.auth.service;

import com.example.auth.domain.RefreshToken;
import com.example.auth.domain.Role;
import com.example.auth.domain.User;
import com.example.auth.dto.AuthResponse;
import com.example.auth.dto.LoginRequest;
import com.example.auth.dto.MessageResponse;
import com.example.auth.dto.RefreshRequest;
import com.example.auth.dto.RegisterRequest;
import com.example.auth.dto.RegisterResponse;
import com.example.auth.dto.ResendVerificationRequest;
import com.example.auth.dto.UserProfileResponse;
import com.example.auth.exception.ApiException;
import com.example.auth.repository.RefreshTokenRepository;
import com.example.auth.repository.UserRepository;
import com.example.common.security.JwtTokenService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenService jwtTokenService;
    private final NotificationClient notificationClient;
    private final ProfileService profileService;
    private final long accessTokenMinutes;
    private final long refreshTokenDays;
    private final String publicAuthUrl;

    public AuthService(UserRepository userRepository,
                       RefreshTokenRepository refreshTokenRepository,
                       PasswordEncoder passwordEncoder,
                       JwtTokenService jwtTokenService,
                       NotificationClient notificationClient,
                       ProfileService profileService,
                       @Value("${app.jwt.access-token-minutes}") long accessTokenMinutes,
                       @Value("${app.jwt.refresh-token-days}") long refreshTokenDays,
                       @Value("${app.public-auth-url}") String publicAuthUrl) {
        this.userRepository = userRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenService = jwtTokenService;
        this.notificationClient = notificationClient;
        this.profileService = profileService;
        this.accessTokenMinutes = accessTokenMinutes;
        this.refreshTokenDays = refreshTokenDays;
        this.publicAuthUrl = publicAuthUrl;
    }

    @Transactional
    public RegisterResponse register(RegisterRequest request) {
        String email = normalizeEmail(request.email());
        if (userRepository.existsByEmail(email)) {
            throw new ApiException(HttpStatus.CONFLICT, "User with this email already exists");
        }

        User user = new User();
        user.setName(request.name().trim());
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        user.setRole(Role.USER);
        user.setEmailVerified(false);
        prepareVerification(user);
        userRepository.save(user);

        String link = verificationLink(user.getEmailVerificationToken());
        notificationClient.sendVerificationEmail(user.getEmail(), link, user.getEmailVerificationToken());

        return new RegisterResponse(
                "Registration complete. Confirm email before login.",
                user.getEmailVerificationToken(),
                link
        );
    }

    @Transactional
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(normalizeEmail(request.email()))
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password"));
        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }
        if (!user.isEmailVerified()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Email is not verified");
        }
        return issueTokens(user);
    }

    @Transactional
    public AuthResponse refresh(RefreshRequest request) {
        RefreshToken refreshToken = refreshTokenRepository.findByTokenHash(sha256(request.refreshToken()))
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Invalid refresh token"));
        if (refreshToken.isRevoked() || refreshToken.getExpiresAt().isBefore(Instant.now())) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Refresh token expired or revoked");
        }
        refreshToken.setRevoked(true);
        return issueTokens(refreshToken.getUser());
    }

    @Transactional
    public MessageResponse logout(String refreshTokenValue) {
        refreshTokenRepository.findByTokenHash(sha256(refreshTokenValue))
                .ifPresent(refreshToken -> refreshToken.setRevoked(true));
        return new MessageResponse("Logged out");
    }

    @Transactional
    public MessageResponse verifyEmail(String token) {
        User user = userRepository.findByEmailVerificationToken(token)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Verification token not found"));
        if (user.getEmailVerificationExpiresAt() == null
                || user.getEmailVerificationExpiresAt().isBefore(Instant.now())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Verification token expired");
        }
        user.setEmailVerified(true);
        user.setEmailVerificationToken(null);
        user.setEmailVerificationExpiresAt(null);
        return new MessageResponse("Email verified. You can login now.");
    }

    @Transactional
    public MessageResponse resendVerification(ResendVerificationRequest request) {
        User user = userRepository.findByEmail(normalizeEmail(request.email()))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "User not found"));
        if (user.isEmailVerified()) {
            return new MessageResponse("Email is already verified");
        }
        prepareVerification(user);
        String link = verificationLink(user.getEmailVerificationToken());
        notificationClient.sendVerificationEmail(user.getEmail(), link, user.getEmailVerificationToken());
        return new MessageResponse("Verification email generated");
    }

    private AuthResponse issueTokens(User user) {
        Duration accessLifetime = Duration.ofMinutes(accessTokenMinutes);
        String accessToken = jwtTokenService.createAccessToken(
                user.getId(),
                user.getEmail(),
                List.of(user.getRole().name()),
                user.isEmailVerified(),
                accessLifetime
        );
        String refreshTokenValue = UUID.randomUUID() + "." + UUID.randomUUID();

        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setTokenHash(sha256(refreshTokenValue));
        refreshToken.setUser(user);
        refreshToken.setExpiresAt(Instant.now().plus(Duration.ofDays(refreshTokenDays)));
        refreshTokenRepository.save(refreshToken);

        UserProfileResponse profile = profileService.toProfileResponse(user);
        return new AuthResponse(accessToken, refreshTokenValue, "Bearer", accessLifetime.toSeconds(), profile);
    }

    private void prepareVerification(User user) {
        user.setEmailVerificationToken(UUID.randomUUID().toString());
        user.setEmailVerificationExpiresAt(Instant.now().plus(Duration.ofHours(24)));
    }

    private String verificationLink(String token) {
        return publicAuthUrl + "/api/auth/verify-email?token=" + token;
    }

    private String normalizeEmail(String email) {
        return email.trim().toLowerCase();
    }

    public static String sha256(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(bytes);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is not available", exception);
        }
    }
}
