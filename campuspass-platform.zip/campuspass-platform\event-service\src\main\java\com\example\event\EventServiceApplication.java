package com.example.event;

import com.example.event.domain.Event;
import com.example.event.repository.EventRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@SpringBootApplication
public class EventServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(EventServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner seedEvents(EventRepository eventRepository) {
        return args -> {
            if (eventRepository.count() > 0) {
                return;
            }
            eventRepository.save(createEvent(
                    "Night Lab: Robotics Sprint",
                    "A practical evening for student teams building small autonomous devices and pitching prototypes.",
                    "Engineering block, lab 3.14",
                    36,
                    Instant.now().plus(12, ChronoUnit.DAYS)
            ));
            eventRepository.save(createEvent(
                    "Portfolio Clinic",
                    "Mentors review CVs, GitHub profiles and project stories before internship season.",
                    "Career center, room B-204",
                    22,
                    Instant.now().plus(7, ChronoUnit.DAYS)
            ));
            eventRepository.save(createEvent(
                    "Data Breakfast",
                    "Short talks about analytics, dashboards and using metrics without making unreadable reports.",
                    "Library cafe",
                    45,
                    Instant.now().plus(18, ChronoUnit.DAYS)
            ));
            eventRepository.save(createEvent(
                    "Design Review Jam",
                    "Small group review for interface prototypes, product flows and presentation polish.",
                    "Media studio",
                    18,
                    Instant.now().plus(24, ChronoUnit.DAYS)
            ));
        };
    }

    private Event createEvent(String title, String description, String location, int capacity, Instant startsAt) {
        Event event = new Event();
        event.setTitle(title);
        event.setDescription(description);
        event.setLocation(location);
        event.setCapacity(capacity);
        event.setStartsAt(startsAt);
        event.setPublished(true);
        return event;
    }
}
