package com.example.notification.controller;

import com.example.notification.dto.EmailNotificationRequest;
import com.example.notification.dto.NotificationResponse;
import com.example.notification.service.NotificationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @PostMapping("/email")
    NotificationResponse create(@Valid @RequestBody EmailNotificationRequest request) {
        return notificationService.create(request);
    }

    @GetMapping
    List<NotificationResponse> findAll() {
        return notificationService.findAll();
    }

    @GetMapping("/by-email")
    List<NotificationResponse> findByEmail(@RequestParam String email) {
        return notificationService.findByRecipient(email);
    }
}
