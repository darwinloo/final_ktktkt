package com.example.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class JwtTokenService {
    private final SecretKey key;
    private final String issuer;
    private final Clock clock;

    public JwtTokenService(String secret, String issuer) {
        this(secret, issuer, Clock.systemUTC());
    }

    public JwtTokenService(String secret, String issuer, Clock clock) {
        if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
            throw new IllegalArgumentException("JWT secret must contain at least 32 bytes");
        }
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.issuer = issuer;
        this.clock = clock;
    }

    public String createAccessToken(UUID userId,
                                    String email,
                                    Collection<String> roles,
                                    boolean emailVerified,
                                    Duration lifetime) {
        Instant now = Instant.now(clock);
        return Jwts.builder()
                .issuer(issuer)
                .subject(email)
                .claim("type", "access")
                .claim("userId", userId.toString())
                .claim("roles", roles)
                .claim("emailVerified", emailVerified)
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(lifetime)))
                .signWith(key)
                .compact();
    }

    public JwtPrincipal parseAccessToken(String token) {
        Claims claims = parseClaims(token);
        if (!"access".equals(claims.get("type", String.class))) {
            throw new JwtException("Unexpected token type");
        }
        return new JwtPrincipal(
                UUID.fromString(claims.get("userId", String.class)),
                claims.getSubject(),
                readRoles(claims.get("roles")),
                Boolean.TRUE.equals(claims.get("emailVerified", Boolean.class))
        );
    }

    private Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .requireIssuer(issuer)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private List<String> readRoles(Object rolesClaim) {
        if (!(rolesClaim instanceof Collection<?> rawRoles)) {
            return List.of();
        }
        List<String> roles = new ArrayList<>();
        for (Object role : rawRoles) {
            if (role != null) {
                roles.add(role.toString());
            }
        }
        return List.copyOf(roles);
    }
}
