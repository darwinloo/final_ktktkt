package com.example.event.repository;

import com.example.event.domain.ApplicationStatus;
import com.example.event.domain.EventApplication;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface EventApplicationRepository extends JpaRepository<EventApplication, UUID> {
    boolean existsByEvent_IdAndUserIdAndStatusNot(UUID eventId, UUID userId, ApplicationStatus status);

    long countByEvent_IdAndStatus(UUID eventId, ApplicationStatus status);

    List<EventApplication> findByUserIdOrderByCreatedAtDesc(UUID userId);

    java.util.Optional<EventApplication> findByIdAndUserId(UUID id, UUID userId);

    List<EventApplication> findAllByOrderByCreatedAtDesc();
}
