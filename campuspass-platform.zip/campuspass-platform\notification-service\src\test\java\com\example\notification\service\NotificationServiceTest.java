package com.example.notification.service;

import com.example.notification.domain.Notification;
import com.example.notification.repository.NotificationRepository;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class NotificationServiceTest {
    @Test
    void createFromEventStoresEmailNotification() {
        NotificationRepository repository = mock(NotificationRepository.class);
        when(repository.save(any(Notification.class))).thenAnswer(invocation -> invocation.getArgument(0));
        NotificationService service = new NotificationService(repository);

        var response = service.createFromEvent(Map.of(
                "to", "user@example.com",
                "subject", "Email verification",
                "body", "Confirm your account",
                "type", "EMAIL_VERIFICATION",
                "verificationToken", "abc"
        ));

        assertThat(response.recipient()).isEqualTo("user@example.com");
        assertThat(response.type()).isEqualTo("EMAIL_VERIFICATION");
        assertThat(response.metadata()).contains("verificationToken=abc");
    }
}
