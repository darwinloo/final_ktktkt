package com.example.gateway.service;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Enumeration;
import java.util.Set;

@Service
public class ProxyService {
    private static final Set<String> SKIPPED_REQUEST_HEADERS = Set.of(
            "host",
            "content-length",
            "connection",
            "transfer-encoding",
            "expect",
            "upgrade"
    );
    private static final Set<String> SKIPPED_RESPONSE_HEADERS = Set.of(
            "content-length",
            "connection",
            "transfer-encoding",
            "upgrade"
    );

    private final RouteResolver routeResolver;
    private final HttpClient httpClient;

    public ProxyService(RouteResolver routeResolver) {
        this.routeResolver = routeResolver;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    public ResponseEntity<byte[]> forward(HttpServletRequest request, byte[] body)
            throws IOException, InterruptedException {
        String path = request.getRequestURI();
        String targetBaseUrl = routeResolver.resolve(path);
        URI targetUri = buildTargetUri(targetBaseUrl, path, request.getQueryString());

        HttpRequest.Builder builder = HttpRequest.newBuilder(targetUri)
                .timeout(Duration.ofSeconds(30));
        copyRequestHeaders(request, builder);

        HttpRequest.BodyPublisher publisher = body == null || body.length == 0
                ? HttpRequest.BodyPublishers.noBody()
                : HttpRequest.BodyPublishers.ofByteArray(body);
        builder.method(request.getMethod(), publisher);

        HttpResponse<byte[]> response = httpClient.send(builder.build(), HttpResponse.BodyHandlers.ofByteArray());

        HttpHeaders responseHeaders = new HttpHeaders();
        response.headers().map().forEach((name, values) -> {
            if (!SKIPPED_RESPONSE_HEADERS.contains(name.toLowerCase())) {
                responseHeaders.addAll(name, values);
            }
        });
        return new ResponseEntity<>(response.body(), responseHeaders, HttpStatusCode.valueOf(response.statusCode()));
    }

    private URI buildTargetUri(String baseUrl, String path, String queryString) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseUrl + path);
        if (queryString != null && !queryString.isBlank()) {
            builder.query(queryString);
        }
        return builder.build(true).toUri();
    }

    private void copyRequestHeaders(HttpServletRequest request, HttpRequest.Builder builder) {
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            if (SKIPPED_REQUEST_HEADERS.contains(headerName.toLowerCase())) {
                continue;
            }
            Enumeration<String> values = request.getHeaders(headerName);
            while (values.hasMoreElements()) {
                builder.header(headerName, values.nextElement());
            }
        }
    }
}
