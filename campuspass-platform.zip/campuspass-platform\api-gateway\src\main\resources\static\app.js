const state = {
  accessToken: localStorage.getItem('accessToken') || '',
  refreshToken: localStorage.getItem('refreshToken') || '',
  profile: readJson('profile'),
  verificationToken: ''
};

const els = {
  sessionLabel: document.getElementById('sessionLabel'),
  logoutBtn: document.getElementById('logoutBtn'),
  authPanel: document.getElementById('authPanel'),
  toast: document.getElementById('toast'),
  eventsList: document.getElementById('eventsList'),
  myApplicationsList: document.getElementById('myApplicationsList'),
  adminApplicationsList: document.getElementById('adminApplicationsList'),
  notificationsList: document.getElementById('notificationsList'),
  profileImages: document.getElementById('profileImages'),
  verificationBox: document.getElementById('verificationBox'),
  verificationText: document.getElementById('verificationText')
};

document.addEventListener('DOMContentLoaded', () => {
  bindNavigation();
  bindForms();
  bindButtons();
  updateSessionUi();
  loadEvents();
  if (state.accessToken) {
    loadProfile();
    loadMyApplications();
  }
});

function bindNavigation() {
  document.querySelectorAll('.nav-item').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach((item) => item.classList.remove('active'));
      document.querySelectorAll('.view').forEach((view) => view.classList.remove('active'));
      button.classList.add('active');
      document.getElementById(`${button.dataset.view}View`).classList.add('active');
      lazyLoad(button.dataset.view);
    });
  });
}

function bindForms() {
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  document.getElementById('registerForm').addEventListener('submit', handleRegister);
  document.getElementById('profileForm').addEventListener('submit', handleProfileUpdate);
  document.getElementById('securityForm').addEventListener('submit', handleSecurityCodeUpdate);
  document.getElementById('imageForm').addEventListener('submit', handleImageUpload);
  document.getElementById('eventForm').addEventListener('submit', handleEventCreate);
}

function bindButtons() {
  els.logoutBtn.addEventListener('click', logout);
  document.getElementById('verifyEmailBtn').addEventListener('click', verifyRegisteredEmail);
  document.getElementById('refreshEventsBtn').addEventListener('click', loadEvents);
  document.getElementById('refreshMyApplicationsBtn').addEventListener('click', loadMyApplications);
  document.getElementById('refreshProfileBtn').addEventListener('click', loadProfile);
  document.getElementById('refreshAdminBtn').addEventListener('click', loadAdminApplications);
  document.getElementById('refreshNotificationsBtn').addEventListener('click', loadNotifications);
}

async function handleLogin(event) {
  event.preventDefault();
  const data = formData(event.target);
  const response = await api('/api/auth/login', {
    method: 'POST',
    body: data,
    anonymous: true
  });

  state.accessToken = response.accessToken;
  state.refreshToken = response.refreshToken;
  state.profile = response.profile;
  localStorage.setItem('accessToken', state.accessToken);
  localStorage.setItem('refreshToken', state.refreshToken);
  localStorage.setItem('profile', JSON.stringify(state.profile));
  updateSessionUi();
  showToast('Signed in');
  await Promise.all([loadEvents(), loadProfile(), loadMyApplications()]);
  if (isAdmin()) {
    loadAdminApplications();
  }
}

async function handleRegister(event) {
  event.preventDefault();
  const response = await api('/api/auth/register', {
    method: 'POST',
    body: formData(event.target),
    anonymous: true
  });
  state.verificationToken = response.verificationToken;
  els.verificationText.textContent = `Verification token: ${response.verificationToken}`;
  els.verificationBox.classList.remove('hidden');
  showToast('Account created. Confirm email with the study token.');
}

async function verifyRegisteredEmail() {
  if (!state.verificationToken) {
    showToast('Register a user first', true);
    return;
  }
  await api(`/api/auth/verify-email?token=${encodeURIComponent(state.verificationToken)}`, {
    anonymous: true
  });
  els.verificationBox.classList.add('hidden');
  showToast('Email confirmed. You can sign in now.');
}

async function loadEvents() {
  const events = await api('/api/events', { anonymous: true });
  if (!events.length) {
    els.eventsList.innerHTML = '<div class="empty">No activities are published yet.</div>';
    return;
  }
  els.eventsList.innerHTML = events.map((event) => `
    <article class="event-card">
      <div>
        <h2>${escapeHtml(event.title)}</h2>
        <p>${escapeHtml(event.description)}</p>
      </div>
      <div class="event-meta">
        <span class="pill">${formatDate(event.startsAt)}</span>
        <span class="pill">${escapeHtml(event.location)}</span>
        <span class="pill">${event.capacity} seats</span>
      </div>
      <form class="application-form" data-event-id="${event.id}">
        <label>Request note<textarea name="comment" rows="3">I want to join this session</textarea></label>
        <button class="button primary" type="submit" ${state.accessToken ? '' : 'disabled'}>Submit request</button>
      </form>
    </article>
  `).join('');

  document.querySelectorAll('.application-form').forEach((form) => {
    form.addEventListener('submit', handleApplicationSubmit);
  });
}

async function handleApplicationSubmit(event) {
  event.preventDefault();
  requireLogin();
  const eventId = event.currentTarget.dataset.eventId;
  await api(`/api/events/${eventId}/applications`, {
    method: 'POST',
    body: formData(event.currentTarget)
  });
  showToast('Request submitted');
  loadMyApplications();
}

async function loadMyApplications() {
  if (!state.accessToken) {
    els.myApplicationsList.innerHTML = '<div class="empty">Sign in to see your requests.</div>';
    return;
  }
  const applications = await api('/api/applications/me');
  els.myApplicationsList.innerHTML = renderApplicationsTable(applications, { own: true });
  document.querySelectorAll('[data-cancel-application]').forEach((button) => {
    button.addEventListener('click', async () => {
      await api(`/api/applications/${button.dataset.cancelApplication}/cancel`, { method: 'PATCH' });
      showToast('Request cancelled');
      loadMyApplications();
    });
  });
}

async function loadProfile() {
  if (!state.accessToken) {
    return;
  }
  const profile = await api('/api/profile/me');
  state.profile = profile;
  localStorage.setItem('profile', JSON.stringify(profile));
  updateSessionUi();

  const form = document.getElementById('profileForm');
  form.elements.name.value = profile.name || '';
  form.elements.bio.value = profile.bio || '';
  await renderProfileImages(profile.images || []);
}

async function handleProfileUpdate(event) {
  event.preventDefault();
  requireLogin();
  await api('/api/profile/me', {
    method: 'PUT',
    body: formData(event.target)
  });
  showToast('Profile updated');
  loadProfile();
}

async function handleSecurityCodeUpdate(event) {
  event.preventDefault();
  requireLogin();
  await api('/api/profile/security-code', {
    method: 'POST',
    body: formData(event.target)
  });
  showToast('Action code updated');
}

async function handleImageUpload(event) {
  event.preventDefault();
  requireLogin();
  const data = new FormData(event.target);
  if (!data.get('file') || !data.get('file').name) {
    showToast('Choose an image file', true);
    return;
  }
  await api('/api/profile/images', {
    method: 'POST',
    body: data,
    rawBody: true
  });
  event.target.reset();
  showToast('Image uploaded');
  loadProfile();
}

async function renderProfileImages(images) {
  if (!images.length) {
    els.profileImages.innerHTML = '<div class="empty">No profile images yet.</div>';
    return;
  }

  const tiles = [];
  for (const image of images) {
    let src = '';
    try {
      const response = await fetch(image.url, {
        headers: authHeaders()
      });
      if (response.ok) {
        src = URL.createObjectURL(await response.blob());
      }
    } catch (error) {
      src = '';
    }
    tiles.push(`
      <div class="image-tile">
        ${src ? `<img src="${src}" alt="${escapeHtml(image.fileName)}">` : '<div class="empty">No preview</div>'}
        <button class="button danger" type="button" data-delete-image="${image.id}">Delete</button>
      </div>
    `);
  }
  els.profileImages.innerHTML = tiles.join('');
  document.querySelectorAll('[data-delete-image]').forEach((button) => {
    button.addEventListener('click', async () => {
      const securityCode = prompt('Enter action code to delete image');
      if (!securityCode) {
        return;
      }
      await api(`/api/profile/images/${button.dataset.deleteImage}`, {
        method: 'DELETE',
        headers: {
          'X-Security-Code': securityCode
        }
      });
      showToast('Image deleted');
      loadProfile();
    });
  });
}

async function handleEventCreate(event) {
  event.preventDefault();
  requireAdmin();
  const data = formData(event.target);
  const securityCode = data.securityCode;
  delete data.securityCode;
  data.capacity = Number(data.capacity);
  data.published = Boolean(data.published);
  data.startsAt = new Date(data.startsAt).toISOString();
  await api('/api/events', {
    method: 'POST',
    body: data,
    headers: {
      'X-Security-Code': securityCode
    }
  });
  event.target.reset();
  event.target.elements.capacity.value = 30;
  event.target.elements.published.checked = true;
  showToast('Activity created');
  loadEvents();
}

async function loadAdminApplications() {
  if (!isAdmin()) {
    els.adminApplicationsList.innerHTML = '<div class="empty">ADMIN or MODERATOR role required.</div>';
    return;
  }
  const applications = await api('/api/admin/applications');
  els.adminApplicationsList.innerHTML = renderApplicationsTable(applications, { admin: true });
  document.querySelectorAll('[data-status-action]').forEach((button) => {
    button.addEventListener('click', async () => {
      const securityCode = document.querySelector(`[data-security-for="${button.dataset.applicationId}"]`).value;
      await api(`/api/admin/applications/${button.dataset.applicationId}/status`, {
        method: 'PATCH',
        headers: {
          'X-Security-Code': securityCode
        },
        body: {
          status: button.dataset.statusAction,
          moderatorComment: button.dataset.statusAction === 'APPROVED' ? 'Approved from review desk' : 'Rejected from review desk'
        }
      });
      showToast('Request status updated');
      loadAdminApplications();
    });
  });
}

async function loadNotifications() {
  const notifications = await api('/api/notifications', { anonymous: true });
  if (!notifications.length) {
    els.notificationsList.innerHTML = '<div class="empty">No notification records yet.</div>';
    return;
  }
  els.notificationsList.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Recipient</th>
          <th>Type</th>
          <th>Subject</th>
          <th>Message</th>
        </tr>
      </thead>
      <tbody>
        ${notifications.map((item) => `
          <tr>
            <td>${formatDate(item.createdAt)}</td>
            <td>${escapeHtml(item.recipient)}</td>
            <td>${escapeHtml(item.type)}</td>
            <td>${escapeHtml(item.subject)}</td>
            <td>${escapeHtml(item.body)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderApplicationsTable(applications, options) {
  if (!applications.length) {
    return '<div class="empty">No requests yet.</div>';
  }
  return `
    <table>
      <thead>
        <tr>
          <th>Activity</th>
          <th>User</th>
          <th>Status</th>
          <th>Comment</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${applications.map((item) => `
          <tr>
            <td>${escapeHtml(item.eventTitle)}</td>
            <td>${escapeHtml(item.userEmail)}</td>
            <td><span class="pill ${statusClass(item.status)}">${escapeHtml(item.status)}</span></td>
            <td>${escapeHtml(item.comment || item.moderatorComment || '')}</td>
            <td>${formatDate(item.createdAt)}</td>
            <td>${renderApplicationActions(item, options)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderApplicationActions(item, options) {
  if (options.admin) {
    return `
      <div class="status-row">
        <input data-security-for="${item.id}" type="password" value="8642" aria-label="Action code">
        <button class="button primary" data-application-id="${item.id}" data-status-action="APPROVED" type="button">Approve</button>
        <button class="button warn" data-application-id="${item.id}" data-status-action="REJECTED" type="button">Reject</button>
      </div>
    `;
  }
  if (options.own && item.status === 'PENDING') {
    return `<button class="button ghost" data-cancel-application="${item.id}" type="button">Cancel</button>`;
  }
  return '<span class="pill">No actions</span>';
}

function lazyLoad(view) {
  if (view === 'events') {
    loadEvents();
  }
  if (view === 'applications') {
    loadMyApplications();
  }
  if (view === 'profile') {
    loadProfile();
  }
  if (view === 'admin') {
    loadAdminApplications();
  }
  if (view === 'notifications') {
    loadNotifications();
  }
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (!options.rawBody) {
    headers.set('Content-Type', 'application/json');
  }
  if (!options.anonymous && state.accessToken) {
    headers.set('Authorization', `Bearer ${state.accessToken}`);
  }

  const response = await fetch(path, {
    method: options.method || 'GET',
    headers,
    body: options.body
      ? options.rawBody ? options.body : JSON.stringify(options.body)
      : undefined
  });

  const text = await response.text();
  const payload = text ? tryParseJson(text) : null;
  if (!response.ok) {
    const message = payload?.message || payload?.error || text || `HTTP ${response.status}`;
    showToast(message, true);
    throw new Error(message);
  }
  return payload;
}

function formData(form) {
  const data = {};
  new FormData(form).forEach((value, key) => {
    if (value instanceof File) {
      data[key] = value;
    } else {
      data[key] = value;
    }
  });
  form.querySelectorAll('input[type="checkbox"]').forEach((input) => {
    data[input.name] = input.checked;
  });
  return data;
}

function authHeaders() {
  return state.accessToken ? { Authorization: `Bearer ${state.accessToken}` } : {};
}

function updateSessionUi() {
  const profile = state.profile;
  if (state.accessToken && profile) {
    els.sessionLabel.textContent = `${profile.email} · ${profile.role}`;
    els.logoutBtn.classList.remove('hidden');
    els.authPanel.classList.add('hidden');
  } else {
    els.sessionLabel.textContent = 'Guest session';
    els.logoutBtn.classList.add('hidden');
    els.authPanel.classList.remove('hidden');
  }
  document.querySelectorAll('.admin-only').forEach((element) => {
    element.classList.toggle('hidden', !isAdmin());
  });
}

function logout() {
  state.accessToken = '';
  state.refreshToken = '';
  state.profile = null;
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
  localStorage.removeItem('profile');
  updateSessionUi();
  loadEvents();
  els.myApplicationsList.innerHTML = '<div class="empty">Sign in to see your requests.</div>';
  showToast('Signed out');
}

function requireLogin() {
  if (!state.accessToken) {
    throw new Error('Sign in required');
  }
}

function requireAdmin() {
  requireLogin();
  if (!isAdmin()) {
    throw new Error('ADMIN or MODERATOR role required');
  }
}

function isAdmin() {
  return state.profile && ['ADMIN', 'MODERATOR'].includes(state.profile.role);
}

function showToast(message, error = false) {
  els.toast.textContent = message;
  els.toast.classList.toggle('error', error);
  els.toast.classList.remove('hidden');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => els.toast.classList.add('hidden'), 5000);
}

function statusClass(status) {
  return String(status || '').toLowerCase();
}

function formatDate(value) {
  if (!value) {
    return '';
  }
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date(value));
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function readJson(key) {
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch (error) {
    return null;
  }
}

function tryParseJson(text) {
  try {
    return JSON.parse(text);
  } catch (error) {
    return text;
  }
}
