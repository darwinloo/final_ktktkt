package com.example.notification.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import java.util.Map;

public record EmailNotificationRequest(
        @NotBlank @Email String to,
        @NotBlank String subject,
        @NotBlank String body,
        @NotBlank String type,
        Map<String, String> metadata
) {
}
