package com.example.event.dto;

import java.time.Instant;
import java.util.UUID;

public record EventResponse(
        UUID id,
        String title,
        String description,
        String location,
        Instant startsAt,
        int capacity,
        boolean published,
        Instant createdAt,
        Instant updatedAt
) {
}
