package com.example.event.domain;

public enum ApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
