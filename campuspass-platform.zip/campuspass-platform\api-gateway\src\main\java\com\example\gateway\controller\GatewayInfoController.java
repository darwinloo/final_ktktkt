package com.example.gateway.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class GatewayInfoController {
    @GetMapping("/api/gateway")
    Map<String, Object> index() {
        return Map.of(
                "service", "api-gateway",
                "status", "UP",
                "baseUrl", "http://localhost:8080",
                "routes", List.of(
                        "/api/auth/**",
                        "/api/profile/**",
                        "/api/events/**",
                        "/api/applications/**",
                        "/api/admin/**",
                        "/api/notifications/**"
                )
        );
    }
}
