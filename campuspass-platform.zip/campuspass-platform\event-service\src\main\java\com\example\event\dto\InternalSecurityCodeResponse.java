package com.example.event.dto;

public record InternalSecurityCodeResponse(boolean valid) {
}
