package com.example.auth.service;

import com.example.auth.domain.ProfileImage;
import com.example.auth.domain.User;
import com.example.auth.dto.ChangeEmailRequest;
import com.example.auth.dto.MessageResponse;
import com.example.auth.dto.ProfileImageResponse;
import com.example.auth.dto.SetSecurityCodeRequest;
import com.example.auth.dto.UpdateProfileRequest;
import com.example.auth.dto.UserProfileResponse;
import com.example.auth.exception.ApiException;
import com.example.auth.repository.ProfileImageRepository;
import com.example.auth.repository.UserRepository;
import com.example.common.security.JwtPrincipal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

@Service
public class ProfileService {
    private static final int MAX_PROFILE_IMAGES = 5;

    private final UserRepository userRepository;
    private final ProfileImageRepository profileImageRepository;
    private final PasswordEncoder passwordEncoder;
    private final NotificationClient notificationClient;
    private final String publicAuthUrl;

    public ProfileService(UserRepository userRepository,
                          ProfileImageRepository profileImageRepository,
                          PasswordEncoder passwordEncoder,
                          NotificationClient notificationClient,
                          @Value("${app.public-auth-url}") String publicAuthUrl) {
        this.userRepository = userRepository;
        this.profileImageRepository = profileImageRepository;
        this.passwordEncoder = passwordEncoder;
        this.notificationClient = notificationClient;
        this.publicAuthUrl = publicAuthUrl;
    }

    @Transactional(readOnly = true)
    public UserProfileResponse currentProfile() {
        return toProfileResponse(currentUser());
    }

    @Transactional
    public UserProfileResponse updateProfile(UpdateProfileRequest request) {
        User user = currentUser();
        user.setName(request.name().trim());
        user.setBio(request.bio());
        return toProfileResponse(user);
    }

    @Transactional
    public MessageResponse changeEmail(ChangeEmailRequest request) {
        User user = currentUser();
        requireSecurityCode(user, request.securityCode());
        String newEmail = request.newEmail().trim().toLowerCase();
        if (userRepository.existsByEmail(newEmail)) {
            throw new ApiException(HttpStatus.CONFLICT, "Email is already used");
        }
        user.setEmail(newEmail);
        user.setEmailVerified(false);
        user.setEmailVerificationToken(UUID.randomUUID().toString());
        user.setEmailVerificationExpiresAt(Instant.now().plus(Duration.ofHours(24)));
        String link = publicAuthUrl + "/api/auth/verify-email?token=" + user.getEmailVerificationToken();
        notificationClient.sendVerificationEmail(user.getEmail(), link, user.getEmailVerificationToken());
        return new MessageResponse("Email changed. Confirm the new email before next login.");
    }

    @Transactional
    public MessageResponse setSecurityCode(SetSecurityCodeRequest request) {
        User user = currentUser();
        if (user.getSecurityCodeHash() != null) {
            requireSecurityCode(user, request.currentSecurityCode());
        }
        user.setSecurityCodeHash(passwordEncoder.encode(request.newSecurityCode()));
        return new MessageResponse("Security code updated");
    }

    @Transactional
    public ProfileImageResponse uploadImage(MultipartFile file) {
        if (file.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Image file is empty");
        }
        if (file.getContentType() == null || !file.getContentType().startsWith("image/")) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Only image files are allowed");
        }

        User user = currentUser();
        if (profileImageRepository.countByUser_Id(user.getId()) >= MAX_PROFILE_IMAGES) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Profile can contain only 5 images");
        }

        try {
            ProfileImage image = new ProfileImage();
            image.setUser(user);
            image.setFileName(file.getOriginalFilename() == null ? "profile-image" : file.getOriginalFilename());
            image.setContentType(file.getContentType());
            image.setSize(file.getSize());
            image.setData(file.getBytes());
            profileImageRepository.save(image);
            return toImageResponse(image);
        } catch (IOException exception) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Cannot read uploaded image");
        }
    }

    @Transactional(readOnly = true)
    public ProfileImage getCurrentUserImage(UUID imageId) {
        JwtPrincipal principal = currentPrincipal();
        return profileImageRepository.findByIdAndUser_Id(imageId, principal.userId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Profile image not found"));
    }

    @Transactional
    public MessageResponse deleteImage(UUID imageId, String securityCode) {
        User user = currentUser();
        requireSecurityCode(user, securityCode);
        ProfileImage image = profileImageRepository.findByIdAndUser_Id(imageId, user.getId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Profile image not found"));
        profileImageRepository.delete(image);
        return new MessageResponse("Profile image deleted");
    }

    @Transactional(readOnly = true)
    public boolean validateSecurityCode(UUID userId, String securityCode) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "User not found"));
        if (user.getSecurityCodeHash() == null) {
            return false;
        }
        return passwordEncoder.matches(securityCode, user.getSecurityCodeHash());
    }

    public UserProfileResponse toProfileResponse(User user) {
        return new UserProfileResponse(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole(),
                user.getBio(),
                user.isEmailVerified(),
                user.getImages().stream().map(this::toImageResponse).toList()
        );
    }

    private ProfileImageResponse toImageResponse(ProfileImage image) {
        return new ProfileImageResponse(
                image.getId(),
                image.getFileName(),
                image.getContentType(),
                image.getSize(),
                "/api/profile/images/" + image.getId()
        );
    }

    private User currentUser() {
        JwtPrincipal principal = currentPrincipal();
        return userRepository.findById(principal.userId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "User not found"));
    }

    private JwtPrincipal currentPrincipal() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof JwtPrincipal principal)) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Authentication required");
        }
        return principal;
    }

    private void requireSecurityCode(User user, String securityCode) {
        if (securityCode == null || user.getSecurityCodeHash() == null
                || !passwordEncoder.matches(securityCode, user.getSecurityCodeHash())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Invalid security code");
        }
    }
}
