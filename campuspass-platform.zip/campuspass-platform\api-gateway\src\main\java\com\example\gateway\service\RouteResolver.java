package com.example.gateway.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class RouteResolver {
    private final String authServiceUrl;
    private final String eventServiceUrl;
    private final String notificationServiceUrl;

    public RouteResolver(@Value("${app.routes.auth-service-url}") String authServiceUrl,
                         @Value("${app.routes.event-service-url}") String eventServiceUrl,
                         @Value("${app.routes.notification-service-url}") String notificationServiceUrl) {
        this.authServiceUrl = stripTrailingSlash(authServiceUrl);
        this.eventServiceUrl = stripTrailingSlash(eventServiceUrl);
        this.notificationServiceUrl = stripTrailingSlash(notificationServiceUrl);
    }

    public String resolve(String path) {
        if (path.startsWith("/api/auth") || path.startsWith("/api/profile") || path.startsWith("/internal")) {
            return authServiceUrl;
        }
        if (path.startsWith("/api/events") || path.startsWith("/api/applications") || path.startsWith("/api/admin")) {
            return eventServiceUrl;
        }
        if (path.startsWith("/api/notifications")) {
            return notificationServiceUrl;
        }
        throw new IllegalArgumentException("No route for path: " + path);
    }

    private String stripTrailingSlash(String value) {
        if (value.endsWith("/")) {
            return value.substring(0, value.length() - 1);
        }
        return value;
    }
}
