package com.example.gateway.controller;

import com.example.gateway.service.ProxyService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class GatewayController {
    private final ProxyService proxyService;

    public GatewayController(ProxyService proxyService) {
        this.proxyService = proxyService;
    }

    @RequestMapping({
            "/api/auth",
            "/api/auth/**",
            "/api/profile",
            "/api/profile/**",
            "/api/events",
            "/api/events/**",
            "/api/applications",
            "/api/applications/**",
            "/api/admin",
            "/api/admin/**",
            "/api/notifications",
            "/api/notifications/**"
    })
    ResponseEntity<byte[]> proxy(HttpServletRequest request, @RequestBody(required = false) byte[] body)
            throws IOException, InterruptedException {
        return proxyService.forward(request, body);
    }
}
