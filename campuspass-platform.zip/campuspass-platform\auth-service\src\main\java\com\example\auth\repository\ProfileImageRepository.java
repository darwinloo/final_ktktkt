package com.example.auth.repository;

import com.example.auth.domain.ProfileImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface ProfileImageRepository extends JpaRepository<ProfileImage, UUID> {
    long countByUser_Id(UUID userId);

    Optional<ProfileImage> findByIdAndUser_Id(UUID id, UUID userId);
}
