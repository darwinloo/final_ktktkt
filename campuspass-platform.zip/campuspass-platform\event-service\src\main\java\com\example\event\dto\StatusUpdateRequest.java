package com.example.event.dto;

import com.example.event.domain.ApplicationStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record StatusUpdateRequest(
        @NotNull ApplicationStatus status,
        @Size(max = 1000) String moderatorComment
) {
}
