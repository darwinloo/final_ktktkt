package com.example.auth.dto;

public record InternalSecurityCodeResponse(boolean valid) {
}
