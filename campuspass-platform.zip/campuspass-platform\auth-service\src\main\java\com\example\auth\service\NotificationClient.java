package com.example.auth.service;

import com.example.auth.config.RabbitMqConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class NotificationClient {
    private static final Logger log = LoggerFactory.getLogger(NotificationClient.class);

    private final RabbitTemplate rabbitTemplate;

    public NotificationClient(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendVerificationEmail(String to, String verificationLink, String token) {
        try {
            rabbitTemplate.convertAndSend(
                    RabbitMqConfig.NOTIFICATION_EXCHANGE,
                    RabbitMqConfig.EMAIL_ROUTING_KEY,
                    Map.of(
                            "to", to,
                            "subject", "Email verification",
                            "body", "Confirm your account: " + verificationLink,
                            "type", "EMAIL_VERIFICATION",
                            "verificationToken", token,
                            "verificationLink", verificationLink
                    )
            );
        } catch (RuntimeException exception) {
            log.warn("RabbitMQ is unavailable, verification token remains usable: {}", token);
        }
    }
}
