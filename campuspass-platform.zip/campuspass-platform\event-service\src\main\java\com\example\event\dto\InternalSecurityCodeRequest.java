package com.example.event.dto;

import java.util.UUID;

public record InternalSecurityCodeRequest(UUID userId, String securityCode) {
}
