package com.example.event.dto;

import jakarta.validation.constraints.Size;

public record ApplicationRequest(@Size(max = 1000) String comment) {
}
