package com.example.event.dto;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;

public record EventRequest(
        @NotBlank @Size(max = 160) String title,
        @NotBlank @Size(max = 3000) String description,
        @NotBlank @Size(max = 240) String location,
        @NotNull @Future Instant startsAt,
        @Min(1) int capacity,
        boolean published
) {
}
