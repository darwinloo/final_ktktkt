package com.example.event.controller;

import com.example.event.dto.ApplicationRequest;
import com.example.event.dto.ApplicationResponse;
import com.example.event.dto.EventRequest;
import com.example.event.dto.EventResponse;
import com.example.event.dto.MessageResponse;
import com.example.event.dto.StatusUpdateRequest;
import com.example.event.service.EventService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class EventController {
    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/events")
    List<EventResponse> listEvents() {
        return eventService.listPublishedEvents();
    }

    @GetMapping("/events/{eventId}")
    EventResponse getEvent(@PathVariable UUID eventId) {
        return eventService.getPublishedEvent(eventId);
    }

    @PostMapping("/events")
    @PreAuthorize("hasAnyRole('ADMIN','MODERATOR')")
    ResponseEntity<EventResponse> createEvent(@Valid @RequestBody EventRequest request,
                                              @RequestHeader("X-Security-Code") String securityCode) {
        return ResponseEntity.status(HttpStatus.CREATED).body(eventService.createEvent(request, securityCode));
    }

    @PutMapping("/events/{eventId}")
    @PreAuthorize("hasAnyRole('ADMIN','MODERATOR')")
    EventResponse updateEvent(@PathVariable UUID eventId,
                              @Valid @RequestBody EventRequest request,
                              @RequestHeader("X-Security-Code") String securityCode) {
        return eventService.updateEvent(eventId, request, securityCode);
    }

    @DeleteMapping("/events/{eventId}")
    @PreAuthorize("hasAnyRole('ADMIN','MODERATOR')")
    MessageResponse deleteEvent(@PathVariable UUID eventId,
                                @RequestHeader("X-Security-Code") String securityCode) {
        return eventService.deleteEvent(eventId, securityCode);
    }

    @PostMapping("/events/{eventId}/applications")
    @PreAuthorize("isAuthenticated()")
    ResponseEntity<ApplicationResponse> submitApplication(@PathVariable UUID eventId,
                                                          @Valid @RequestBody ApplicationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(eventService.submitApplication(eventId, request));
    }

    @GetMapping("/applications/me")
    @PreAuthorize("isAuthenticated()")
    List<ApplicationResponse> myApplications() {
        return eventService.myApplications();
    }

    @PatchMapping("/applications/{applicationId}/cancel")
    @PreAuthorize("isAuthenticated()")
    ApplicationResponse cancelMyApplication(@PathVariable UUID applicationId) {
        return eventService.cancelMyApplication(applicationId);
    }

    @GetMapping("/admin/applications")
    @PreAuthorize("hasAnyRole('ADMIN','MODERATOR')")
    List<ApplicationResponse> allApplications() {
        return eventService.allApplications();
    }

    @PatchMapping("/admin/applications/{applicationId}/status")
    @PreAuthorize("hasAnyRole('ADMIN','MODERATOR')")
    ApplicationResponse updateStatus(@PathVariable UUID applicationId,
                                     @Valid @RequestBody StatusUpdateRequest request,
                                     @RequestHeader("X-Security-Code") String securityCode) {
        return eventService.updateApplicationStatus(applicationId, request, securityCode);
    }
}
