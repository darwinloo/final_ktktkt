package com.example.event.dto;

public record MessageResponse(String message) {
}
