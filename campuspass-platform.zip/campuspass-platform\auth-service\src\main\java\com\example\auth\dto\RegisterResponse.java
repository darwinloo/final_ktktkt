package com.example.auth.dto;

public record RegisterResponse(
        String message,
        String verificationToken,
        String verificationLink
) {
}
