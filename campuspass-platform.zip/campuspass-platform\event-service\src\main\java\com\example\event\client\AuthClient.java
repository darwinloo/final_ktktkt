package com.example.event.client;

import com.example.event.dto.InternalSecurityCodeRequest;
import com.example.event.dto.InternalSecurityCodeResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.UUID;

@Component
public class AuthClient {
    private final RestClient restClient;
    private final String internalToken;

    public AuthClient(RestClient.Builder restClientBuilder,
                      @Value("${app.auth-service-url}") String authServiceUrl,
                      @Value("${app.internal-token}") String internalToken) {
        this.restClient = restClientBuilder.baseUrl(authServiceUrl).build();
        this.internalToken = internalToken;
    }

    public boolean validateSecurityCode(UUID userId, String securityCode) {
        try {
            InternalSecurityCodeResponse response = restClient.post()
                    .uri("/internal/security-code/validate")
                    .header("X-Internal-Token", internalToken)
                    .body(new InternalSecurityCodeRequest(userId, securityCode))
                    .retrieve()
                    .body(InternalSecurityCodeResponse.class);
            return response != null && response.valid();
        } catch (RuntimeException exception) {
            return false;
        }
    }
}
