package com.example.event.service;

import com.example.common.security.JwtPrincipal;
import com.example.event.client.AuthClient;
import com.example.event.dto.ApplicationRequest;
import com.example.event.exception.ApiException;
import com.example.event.repository.EventApplicationRepository;
import com.example.event.repository.EventRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;

class EventServiceTest {
    @AfterEach
    void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void submitApplicationRequiresVerifiedEmail() {
        EventRepository eventRepository = mock(EventRepository.class);
        EventApplicationRepository applicationRepository = mock(EventApplicationRepository.class);
        AuthClient authClient = mock(AuthClient.class);
        NotificationPublisher notificationPublisher = mock(NotificationPublisher.class);
        EventService eventService = new EventService(
                eventRepository,
                applicationRepository,
                authClient,
                notificationPublisher
        );
        JwtPrincipal principal = new JwtPrincipal(
                UUID.randomUUID(),
                "attendee@campuspass.local",
                List.of("USER"),
                false
        );
        var authentication = new UsernamePasswordAuthenticationToken(
                principal,
                null,
                List.of(new SimpleGrantedAuthority("ROLE_USER"))
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);

        assertThatThrownBy(() -> eventService.submitApplication(UUID.randomUUID(), new ApplicationRequest("Please approve")))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("Email must be verified");
        verifyNoInteractions(eventRepository);
        verifyNoInteractions(applicationRepository);
    }
}
