# CampusPass

Spring Boot microservice project for managing campus activity applications.

The app is exposed through one entry point:

```text
http://localhost:8080
```

The user works with the web UI at this address. The internal services are hidden behind `api-gateway`.

## Architecture

- `api-gateway` - web UI and API proxy.
- `auth-service` - registration, login, JWT, refresh token, email verification, profile, action code and profile images.
- `event-service` - activities, applications and review decisions.
- `notification-service` - study email notification log, fed by RabbitMQ.
- `postgres` - separate databases for services.
- `rabbitmq` - async notification events.

Routes through gateway:

- `/api/auth/**`, `/api/profile/**` -> `auth-service`
- `/api/events/**`, `/api/applications/**`, `/api/admin/**` -> `event-service`
- `/api/notifications/**` -> `notification-service`

Important actions use two protection levels:

1. JWT access token.
2. `X-Security-Code` action code for sensitive admin/profile actions.

## Docker Run

Start Docker Desktop, then run from project root:

```powershell
docker compose up --build
```

Open:

```text
http://localhost:8080
```

Stop:

```powershell
docker compose down
```

If you already started an older version and still see old demo accounts or activities, reset the database volume once:

```powershell
docker compose down -v
docker compose up --build
```

## Seed Accounts

All seed accounts are already email-verified.

Password for all accounts:

```text
Passw0rd!
```

Action code for sensitive actions:

```text
8642
```

| Email | Role |
| --- | --- |
| `owner@campuspass.local` | `ADMIN` |
| `curator@campuspass.local` | `MODERATOR` |
| `attendee@campuspass.local` | `USER` |

## UI Check Flow

1. Open `http://localhost:8080`.
2. Sign in as `attendee@campuspass.local`.
3. Open `Event board`.
4. Submit a request for an activity.
5. Sign out.
6. Sign in as `owner@campuspass.local`.
7. Open `Review desk`.
8. Approve or reject the request with action code `8642`.
9. Open `Mail log` and check notification records.

## API Endpoints

All endpoints are called through `http://localhost:8080`.

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/auth/register` | Register a new user |
| `GET` | `/api/auth/verify-email?token=...` | Confirm email |
| `POST` | `/api/auth/login` | Login and get tokens |
| `POST` | `/api/auth/refresh` | Rotate refresh token |
| `POST` | `/api/auth/logout` | Revoke refresh token |
| `GET` | `/api/profile/me` | Current profile |
| `PUT` | `/api/profile/me` | Update profile |
| `POST` | `/api/profile/images` | Upload profile image, max 5 |
| `DELETE` | `/api/profile/images/{imageId}` | Delete image with action code |
| `GET` | `/api/events` | Published activities |
| `POST` | `/api/events` | Create activity with admin/moderator role and action code |
| `POST` | `/api/events/{eventId}/applications` | Submit application |
| `GET` | `/api/applications/me` | Current user's applications |
| `PATCH` | `/api/applications/{applicationId}/cancel` | Cancel pending application |
| `GET` | `/api/admin/applications` | Review all applications |
| `PATCH` | `/api/admin/applications/{applicationId}/status` | Approve/reject application |
| `GET` | `/api/notifications` | Notification records |

## IntelliJ Run

1. `File -> Open`
2. Select the root `pom.xml`
3. Use `JDK 17`
4. Run infrastructure:

```powershell
docker compose up -d postgres rabbitmq
```

5. Start classes:

```text
NotificationServiceApplication
AuthServiceApplication
EventServiceApplication
ApiGatewayApplication
```

Open `http://localhost:8080`.

## Tests

```powershell
.\mvnw.cmd test
```
