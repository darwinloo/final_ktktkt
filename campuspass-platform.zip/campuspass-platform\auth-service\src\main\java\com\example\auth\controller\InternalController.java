package com.example.auth.controller;

import com.example.auth.dto.InternalSecurityCodeRequest;
import com.example.auth.dto.InternalSecurityCodeResponse;
import com.example.auth.exception.ApiException;
import com.example.auth.service.ProfileService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal")
public class InternalController {
    private final ProfileService profileService;
    private final String internalToken;

    public InternalController(ProfileService profileService,
                              @Value("${app.internal-token}") String internalToken) {
        this.profileService = profileService;
        this.internalToken = internalToken;
    }

    @PostMapping("/security-code/validate")
    InternalSecurityCodeResponse validateSecurityCode(
            @RequestHeader("X-Internal-Token") String token,
            @Valid @RequestBody InternalSecurityCodeRequest request) {
        if (!internalToken.equals(token)) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid internal token");
        }
        return new InternalSecurityCodeResponse(
                profileService.validateSecurityCode(request.userId(), request.securityCode())
        );
    }
}
