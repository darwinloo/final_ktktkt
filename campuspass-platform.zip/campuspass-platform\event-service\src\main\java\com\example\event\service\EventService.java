package com.example.event.service;

import com.example.common.security.JwtPrincipal;
import com.example.event.client.AuthClient;
import com.example.event.domain.ApplicationStatus;
import com.example.event.domain.Event;
import com.example.event.domain.EventApplication;
import com.example.event.dto.ApplicationRequest;
import com.example.event.dto.ApplicationResponse;
import com.example.event.dto.EventRequest;
import com.example.event.dto.EventResponse;
import com.example.event.dto.MessageResponse;
import com.example.event.dto.StatusUpdateRequest;
import com.example.event.exception.ApiException;
import com.example.event.repository.EventApplicationRepository;
import com.example.event.repository.EventRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Service
public class EventService {
    private final EventRepository eventRepository;
    private final EventApplicationRepository applicationRepository;
    private final AuthClient authClient;
    private final NotificationPublisher notificationPublisher;

    public EventService(EventRepository eventRepository,
                        EventApplicationRepository applicationRepository,
                        AuthClient authClient,
                        NotificationPublisher notificationPublisher) {
        this.eventRepository = eventRepository;
        this.applicationRepository = applicationRepository;
        this.authClient = authClient;
        this.notificationPublisher = notificationPublisher;
    }

    @Transactional(readOnly = true)
    public List<EventResponse> listPublishedEvents() {
        return eventRepository.findByPublishedTrueAndStartsAtAfterOrderByStartsAtAsc(Instant.now())
                .stream()
                .map(this::toEventResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public EventResponse getPublishedEvent(UUID eventId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Event not found"));
        if (!event.isPublished()) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Event not found");
        }
        return toEventResponse(event);
    }

    @Transactional
    public EventResponse createEvent(EventRequest request, String securityCode) {
        requireSecondFactor(securityCode);
        Event event = new Event();
        fillEvent(event, request);
        return toEventResponse(eventRepository.save(event));
    }

    @Transactional
    public EventResponse updateEvent(UUID eventId, EventRequest request, String securityCode) {
        requireSecondFactor(securityCode);
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Event not found"));
        fillEvent(event, request);
        return toEventResponse(event);
    }

    @Transactional
    public MessageResponse deleteEvent(UUID eventId, String securityCode) {
        requireSecondFactor(securityCode);
        if (!eventRepository.existsById(eventId)) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Event not found");
        }
        eventRepository.deleteById(eventId);
        return new MessageResponse("Event deleted");
    }

    @Transactional
    public ApplicationResponse submitApplication(UUID eventId, ApplicationRequest request) {
        JwtPrincipal principal = currentPrincipal();
        if (!principal.emailVerified()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Email must be verified before submitting applications");
        }

        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Event not found"));
        if (!event.isPublished()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Event is not available for applications");
        }
        if (applicationRepository.existsByEvent_IdAndUserIdAndStatusNot(
                eventId,
                principal.userId(),
                ApplicationStatus.CANCELLED
        )) {
            throw new ApiException(HttpStatus.CONFLICT, "You already have an active application for this event");
        }

        EventApplication application = new EventApplication();
        application.setEvent(event);
        application.setUserId(principal.userId());
        application.setUserEmail(principal.email());
        application.setComment(request.comment());
        EventApplication savedApplication = applicationRepository.save(application);
        notificationPublisher.applicationSubmitted(savedApplication.getUserEmail(), event.getTitle());
        return toApplicationResponse(savedApplication);
    }

    @Transactional(readOnly = true)
    public List<ApplicationResponse> myApplications() {
        JwtPrincipal principal = currentPrincipal();
        return applicationRepository.findByUserIdOrderByCreatedAtDesc(principal.userId())
                .stream()
                .map(this::toApplicationResponse)
                .toList();
    }

    @Transactional
    public ApplicationResponse cancelMyApplication(UUID applicationId) {
        JwtPrincipal principal = currentPrincipal();
        EventApplication application = applicationRepository.findByIdAndUserId(applicationId, principal.userId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Application not found"));
        if (application.getStatus() == ApplicationStatus.APPROVED) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Approved application cannot be cancelled by user");
        }
        application.setStatus(ApplicationStatus.CANCELLED);
        return toApplicationResponse(application);
    }

    @Transactional(readOnly = true)
    public List<ApplicationResponse> allApplications() {
        return applicationRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toApplicationResponse)
                .toList();
    }

    @Transactional
    public ApplicationResponse updateApplicationStatus(UUID applicationId,
                                                       StatusUpdateRequest request,
                                                       String securityCode) {
        requireSecondFactor(securityCode);
        EventApplication application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Application not found"));
        if (request.status() == ApplicationStatus.APPROVED) {
            long approvedCount = applicationRepository.countByEvent_IdAndStatus(
                    application.getEvent().getId(),
                    ApplicationStatus.APPROVED
            );
            if (approvedCount >= application.getEvent().getCapacity()
                    && application.getStatus() != ApplicationStatus.APPROVED) {
                throw new ApiException(HttpStatus.BAD_REQUEST, "Event capacity is already full");
            }
        }
        application.setStatus(request.status());
        application.setModeratorComment(request.moderatorComment());
        notificationPublisher.applicationStatusChanged(
                application.getUserEmail(),
                application.getEvent().getTitle(),
                application.getStatus()
        );
        return toApplicationResponse(application);
    }

    private void fillEvent(Event event, EventRequest request) {
        event.setTitle(request.title().trim());
        event.setDescription(request.description().trim());
        event.setLocation(request.location().trim());
        event.setStartsAt(request.startsAt());
        event.setCapacity(request.capacity());
        event.setPublished(request.published());
    }

    private void requireSecondFactor(String securityCode) {
        JwtPrincipal principal = currentPrincipal();
        if (securityCode == null || securityCode.isBlank()
                || !authClient.validateSecurityCode(principal.userId(), securityCode)) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Invalid security code");
        }
    }

    private JwtPrincipal currentPrincipal() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof JwtPrincipal principal)) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Authentication required");
        }
        return principal;
    }

    private EventResponse toEventResponse(Event event) {
        return new EventResponse(
                event.getId(),
                event.getTitle(),
                event.getDescription(),
                event.getLocation(),
                event.getStartsAt(),
                event.getCapacity(),
                event.isPublished(),
                event.getCreatedAt(),
                event.getUpdatedAt()
        );
    }

    private ApplicationResponse toApplicationResponse(EventApplication application) {
        return new ApplicationResponse(
                application.getId(),
                application.getEvent().getId(),
                application.getEvent().getTitle(),
                application.getUserId(),
                application.getUserEmail(),
                application.getStatus(),
                application.getComment(),
                application.getModeratorComment(),
                application.getCreatedAt(),
                application.getUpdatedAt()
        );
    }
}
