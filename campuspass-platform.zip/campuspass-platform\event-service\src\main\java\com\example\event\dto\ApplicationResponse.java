package com.example.event.dto;

import com.example.event.domain.ApplicationStatus;

import java.time.Instant;
import java.util.UUID;

public record ApplicationResponse(
        UUID id,
        UUID eventId,
        String eventTitle,
        UUID userId,
        String userEmail,
        ApplicationStatus status,
        String comment,
        String moderatorComment,
        Instant createdAt,
        Instant updatedAt
) {
}
