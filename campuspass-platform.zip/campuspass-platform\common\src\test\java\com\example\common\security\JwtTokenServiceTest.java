package com.example.common.security;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class JwtTokenServiceTest {
    private final JwtTokenService jwtTokenService = new JwtTokenService(
            "test-secret-key-with-at-least-32-characters",
            "test-suite"
    );

    @Test
    void createsAndParsesAccessToken() {
        UUID userId = UUID.randomUUID();

        String token = jwtTokenService.createAccessToken(
                userId,
                "user@example.com",
                List.of("USER"),
                true,
                Duration.ofMinutes(5)
        );

        JwtPrincipal principal = jwtTokenService.parseAccessToken(token);

        assertThat(principal.userId()).isEqualTo(userId);
        assertThat(principal.email()).isEqualTo("user@example.com");
        assertThat(principal.roles()).containsExactly("USER");
        assertThat(principal.emailVerified()).isTrue();
    }
}
