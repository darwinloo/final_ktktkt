package com.example.notification.service;

import com.example.notification.config.RabbitMqConfig;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class EmailNotificationConsumer {
    private final NotificationService notificationService;

    public EmailNotificationConsumer(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @RabbitListener(queues = RabbitMqConfig.EMAIL_QUEUE)
    void handleEmailNotification(Map<String, Object> event) {
        notificationService.createFromEvent(event);
    }
}
